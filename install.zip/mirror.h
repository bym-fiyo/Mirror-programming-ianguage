/*
 * Mirror Language Interpreter
 * Независимый язык программирования
 * 
 * Компиляция:
 *   gcc -o mirror mirror.c -lm
 * 
 * Использование:
 *   mirror program.mirror
 *   mirror --repl
 */

#ifndef MIRROR_H
#define MIRROR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_SOURCE_SIZE (1024 * 1024)
#define MAX_TOKEN_LEN 4096
#define MAX_VARS 1024
#define MAX_STRING_LEN 4096
#define MAX_ARRAY_SIZE 1024

/* ============================================================================
 * TOKENS
 * ============================================================================ */

typedef enum {
    TOK_NUMBER,
    TOK_STRING,
    TOK_BOOL,
    TOK_NULL,
    TOK_IDENT,
    
    /* Keywords */
    TOK_LET, TOK_FN, TOK_RETURN, TOK_IF, TOK_ELSE,
    TOK_LOOP, TOK_WHILE, TOK_FOR, TOK_IN,
    TOK_BREAK, TOK_CONTINUE, TOK_PRINT, TOK_INPUT, TOK_TYPEOF,
    
    /* Operators */
    TOK_PLUS, TOK_MINUS, TOK_STAR, TOK_SLASH, TOK_PERCENT, TOK_POW,
    TOK_EQ, TOK_NEQ, TOK_LT, TOK_GT, TOK_LTE, TOK_GTE,
    TOK_AND, TOK_OR, TOK_NOT,
    TOK_ASSIGN, TOK_SWAP, TOK_ARROW, TOK_PIPE,
    
    /* Delimiters */
    TOK_LPAREN, TOK_RPAREN, TOK_LBRACE, TOK_RBRACE,
    TOK_LBRACKET, TOK_RBRACKET, TOK_COMMA, TOK_COLON, TOK_DOT,
    
    /* Special */
    TOK_NEWLINE, TOK_EOF, TOK_ERROR
} TokenType;

typedef struct {
    TokenType type;
    char value[MAX_TOKEN_LEN];
    int line;
    int column;
} Token;

/* ============================================================================
 * LEXER
 * ============================================================================ */

typedef struct {
    const char* source;
    int pos;
    int line;
    int column;
    Token* tokens;
    int token_count;
    int token_capacity;
} Lexer;

/* ============================================================================
 * AST NODES
 * ============================================================================ */

typedef enum {
    NODE_NUMBER, NODE_STRING, NODE_BOOL, NODE_NULL,
    NODE_IDENT, NODE_ARRAY, NODE_DICT,
    NODE_UNARY, NODE_BINARY,
    NODE_ASSIGN, NODE_INDEX_ASSIGN, NODE_SWAP, NODE_INDEX_SWAP,
    NODE_CALL, NODE_FUNC_CALL, NODE_INDEX, NODE_ATTRIBUTE,
    NODE_BLOCK, NODE_IF, NODE_WHILE, NODE_LOOP, NODE_FOR,
    NODE_RETURN, NODE_BREAK, NODE_CONTINUE, NODE_PRINT, NODE_INPUT,
    NODE_FUNC_DEF, NODE_ARROW, NODE_PIPE, NODE_TYPEOF
} NodeType;

typedef struct ASTNode {
    NodeType type;
    char* value;
    char* op;
    struct ASTNode** children;
    int child_count;
    int child_capacity;
} ASTNode;

/* ============================================================================
 * RUNTIME VALUES
 * ============================================================================ */

typedef enum {
    VAL_NUMBER, VAL_STRING, VAL_BOOL, VAL_NULL,
    VAL_ARRAY, VAL_DICT, VAL_FUNC, VAL_ARROW
} ValueType;

typedef struct Value Value;
typedef struct Function Function;

struct Function {
    char* name;
    char** params;
    int param_count;
    ASTNode* body;
};

struct Value {
    ValueType type;
    union {
        double number;
        char* string;
        bool boolean;
        struct {
            Value** items;
            int count;
            int capacity;
        } array;
        struct {
            char** keys;
            Value** values;
            int count;
            int capacity;
        } dict;
        Function* func;
        struct {
            char** params;
            int param_count;
            ASTNode* body;
        } arrow;
    } data;
};

/* ============================================================================
 * ENVIRONMENT
 * ============================================================================ */

typedef struct Environment {
    char** names;
    Value** values;
    int count;
    struct Environment* parent;
} Environment;

/* ============================================================================
 * PARSER
 * ============================================================================ */

typedef struct {
    Token* tokens;
    int pos;
} Parser;

/* ============================================================================
 * INTERPRETER
 * ============================================================================ */

typedef struct {
    Environment* global_env;
    char error_msg[512];
} Interpreter;

/* ============================================================================
 * FUNCTION DECLARATIONS
 * ============================================================================ */

/* Lexer */
void lexer_init(Lexer* lexer, const char* source);
void lexer_free(Lexer* lexer);
Token* lexer_tokenize(Lexer* lexer, int* count);

/* Parser */
void parser_init(Parser* parser, Token* tokens);
ASTNode* parser_parse(Parser* parser);
void ast_free(ASTNode* node);

/* Runtime */
Value* value_new_number(double n);
Value* value_new_string(const char* s);
Value* value_new_bool(bool b);
Value* value_new_null(void);
Value* value_new_array(void);
Value* value_new_dict(void);
void value_free(Value* v);
Value* value_clone(Value* v);

/* Environment */
Environment* env_new(Environment* parent);
void env_free(Environment* env);
void env_set(Environment* env, const char* name, Value* value);
Value* env_get(Environment* env, const char* name);

/* Interpreter */
void interp_init(Interpreter* interp);
void interp_free(Interpreter* interp);
Value* interp_run(Interpreter* interp, ASTNode* program);
char* value_to_string(Value* v);

/* Builtins */
void setup_builtins(Environment* env);

#endif /* MIRROR_H */
