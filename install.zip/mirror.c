/*
 * Mirror Language Interpreter (C)
 * Полностью независимый интерпретатор
 * Синтаксис: отступы (4 пробела), # комментарии, f-строки, range ..
 * Без фигурных скобок - вложенность через отступы!
 *
 * Компиляция: gcc -o mirror mirror.c -lm -O2
 * Использование: ./mirror program.mirror
 *                ./mirror --repl
 */

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <errno.h>
#include <time.h>
#include <regex.h>
#include <openssl/evp.h>

/* ==================== CONSTANTS ==================== */

#define MAX_CODE_SIZE (1024 * 1024)
#define MAX_TOKEN_LEN 4096
#define MAX_TOKENS 65536
#define MAX_STACK 1024
#define MAX_VARS 2048
#define MAX_LINE 4096
#define MAX_PARAMS 32
#define MAX_ARGS 32
#define MAX_ARRAY_CAP 65536
#define MAX_DICT_CAP 4096
#define INDENT_SIZE 4  /* 4 пробела на уровень отступа */

/* ==================== TOKENS ==================== */

typedef enum {
    /* Literals */
    TOK_NUM, TOK_STR, TOK_FSTR, TOK_BOOL, TOK_NULL, TOK_IDENT,

    /* Keywords */
    TOK_LET, TOK_FN, TOK_MIRFN, TOK_MACRO, TOK_RET, TOK_IF, TOK_ELSE,
    TOK_WHILE, TOK_FOR, TOK_IN, TOK_LOOP,
    TOK_BRK, TOK_CONT, TOK_PRINT, TOK_INPUT, TOK_TYPEOF,
    TOK_STOP, TOK_NEXT,
    TOK_IMPORT, TOK_MATCH, TOK_CASE, TOK_DEFAULT,
    TOK_TRY, TOK_CATCH, TOK_FINALLY, TOK_THROW,
    TOK_CLASS, TOK_PUBLIC, TOK_PRIVATE,
    TOK_NIL,

    /* Operators */
    TOK_PLUS, TOK_MIN, TOK_MUL, TOK_DIV, TOK_MOD, TOK_POW,
    TOK_EQ, TOK_NEQ, TOK_LT, TOK_GT, TOK_LE, TOK_GE,
    TOK_AND, TOK_OR, TOK_NOT,
    TOK_ASSIGN, TOK_SWAP, TOK_ARROW, TOK_PIPE, TOK_DOTDOT,
    TOK_PLUS_EQ, TOK_MIN_EQ, TOK_MUL_EQ, TOK_DIV_EQ,
    TOK_INC, TOK_DEC, TOK_QUESTION, TOK_BANG, TOK_COLON,
    TOK_NULL_COALESCE, TOK_TRIPLEQUOTE,

    /* Delimiters */
    TOK_LPAREN, TOK_RPAREN,
    TOK_LBRACK, TOK_RBRACK, TOK_COMMA, TOK_DOT,
    TOK_LBRACE, TOK_RBRACE,  /* Только для словарей */

    /* Indentation */
    TOK_INDENT, TOK_DEDENT,

    /* Special */
    TOK_NL, TOK_EOF, TOK_ERR
} TokenType;

typedef struct {
    TokenType type;
    char val[MAX_TOKEN_LEN];
    int line, col;
} Token;

/* ==================== LEXER GLOBALS ==================== */

static const char* SRC;
static int POS, LINE = 1, COL = 1;
static Token TOKENS[MAX_TOKENS];
static int TCNT = 0;
static char ERR_MSG[512] = {0};
static int indentStack[256];  /* Стек отступов */
static int indentDepth = 0;   /* Текущая глубина стека */

/* ==================== FORWARD DECLARATIONS ==================== */

typedef struct Val Val;

static char peek(int o);
static char adv();
static void addTok(TokenType t, const char* v);
static bool isKW(const char* s, TokenType* out);
static void tokenize();
static void run(const char* src);
static void runFile(const char* path);
static void freeVal(Val* v);

/* ==================== LEXER ==================== */

static char peek(int o) {
    int p = POS + o;
    const char* s = SRC;
    int len = strlen(s);
    return (p >= len || p < 0) ? '\0' : s[p];
}

static char adv() {
    char c = peek(0);
    POS++;
    if (c == '\n') { LINE++; COL = 1; } else COL++;
    return c;
}

static void addTok(TokenType t, const char* v) {
    if (TCNT >= MAX_TOKENS) {
        snprintf(ERR_MSG, sizeof(ERR_MSG), "Too many tokens");
        return;
    }
    Token* tk = &TOKENS[TCNT++];
    tk->type = t;
    strncpy(tk->val, v, MAX_TOKEN_LEN - 1);
    tk->val[MAX_TOKEN_LEN - 1] = '\0';
    tk->line = LINE;
    tk->col = COL;
}

static bool isKW(const char* s, TokenType* out) {
    static struct { const char* k; TokenType t; } kw[] = {
        {"var", TOK_LET}, {"func", TOK_FN}, {"mirrorfunc", TOK_MIRFN}, {"macro", TOK_MACRO}, {"ret", TOK_RET},
        {"if", TOK_IF}, {"else", TOK_ELSE}, {"while", TOK_WHILE},
        {"for", TOK_FOR}, {"in", TOK_IN}, {"loop", TOK_LOOP},
        {"stop", TOK_STOP}, {"next", TOK_NEXT},
        {"echo", TOK_PRINT}, {"ask", TOK_INPUT}, {"typeof", TOK_TYPEOF},
        {"use", TOK_IMPORT},
        {"switch", TOK_MATCH}, {"case", TOK_CASE}, {"default", TOK_DEFAULT},
        {"try", TOK_TRY}, {"catch", TOK_CATCH}, {"finally", TOK_FINALLY}, {"raise", TOK_THROW},
        {"class", TOK_CLASS}, {"pub", TOK_PUBLIC}, {"priv", TOK_PRIVATE}, {"nil", TOK_NIL},
        {"yes", TOK_BOOL}, {"no", TOK_BOOL}, {"true", TOK_BOOL}, {"false", TOK_BOOL},
        {"and", TOK_AND}, {"or", TOK_OR}, {"not", TOK_NOT},
        {NULL, 0}
    };
    for (int i = 0; kw[i].k; i++)
        if (strcmp(s, kw[i].k) == 0) { *out = kw[i].t; return true; }
    return false;
}

static void tokenize() {
    TCNT = 0;
    LINE = 1; COL = 1; POS = 0;
    indentStack[0] = 0;
    indentDepth = 0;
    bool atLineStart = true;

    while (POS < (int)strlen(SRC)) {
        int sl = LINE, sc = COL;
        char c = peek(0);

        /* Обработка начала строки - отступы */
        if (atLineStart) {
            int indent = 0;
            /* Считаем пробелы */
            while (peek(0) == ' ') {
                indent++;
                adv();
            }
            /* Табуляция = 4 пробела */
            if (peek(0) == '\t') {
                indent += INDENT_SIZE;
                adv();
            }
            
            /* Если строка пустая или комментарий - пропускаем */
            if (peek(0) != '\n' && peek(0) != '#' && peek(0) != '\0') {
                /* Это значимая строка с отступом */
                if (indent > indentStack[indentDepth]) {
                    /* Увеличение отступа - INDENT */
                    if (indent % INDENT_SIZE != 0) {
                        snprintf(ERR_MSG, sizeof(ERR_MSG), 
                            "Indentation error line %d: use multiples of %d spaces (got %d)", 
                            LINE, INDENT_SIZE, indent);
                        return;
                    }
                    if (indentDepth >= 255) {
                        snprintf(ERR_MSG, sizeof(ERR_MSG), "Too many indentation levels");
                        return;
                    }
                    indentStack[++indentDepth] = indent;
                    addTok(TOK_INDENT, "");
                } else if (indent < indentStack[indentDepth]) {
                    /* Уменьшение отступа - DEDENT */
                    while (indentDepth > 0 && indent < indentStack[indentDepth]) {
                        indentDepth--;
                        addTok(TOK_DEDENT, "");
                    }
                    if (indent != indentStack[indentDepth]) {
                        snprintf(ERR_MSG, sizeof(ERR_MSG), 
                            "Inconsistent indentation line %d: expected %d spaces", 
                            LINE, indentStack[indentDepth]);
                        return;
                    }
                }
            }
            atLineStart = false;
        }

        /* Skip whitespace (уже обработали отступы выше) */
        while (peek(0) == ' ' || peek(0) == '\t' || peek(0) == '\r') adv();

        /* Comments - # style */
        if (peek(0) == '#') {
            while (peek(0) && peek(0) != '\n') adv();
            continue;
        }
        /* C-style comments */
        if (peek(0) == '/' && peek(1) == '*') {
            adv(); adv();
            while (peek(0) && !(peek(0) == '*' && peek(1) == '/')) adv();
            if (peek(0) == '*') { adv(); adv(); }
            continue;
        }

        if (!peek(0)) break;

        c = peek(0);

        /* Newline - сбрасываем флаг начала строки */
        if (c == '\n') {
            adv();
            atLineStart = true;
            addTok(TOK_NL, "\\n");
            continue;
        }

        /* f-string with interpolation */
        if (c == 'f' && (peek(1) == '"' || peek(1) == '\'')) {
            adv(); /* skip 'f' */
            char quote = adv(); /* skip opening quote */
            char buf[MAX_TOKEN_LEN];
            int bi = 0;
            while (peek(0) && peek(0) != quote) {
                if (peek(0) == '{') {
                    /* Interpolation start - store up to here */
                    buf[bi] = '\0';
                    addTok(TOK_FSTR, buf);
                    adv(); /* skip { */
                    /* Read expression until } */
                    char expr[MAX_TOKEN_LEN];
                    int ei = 0;
                    int depth = 1;
                    while (peek(0) && depth > 0) {
                        if (peek(0) == '{') depth++;
                        else if (peek(0) == '}') depth--;
                        if (depth > 0) expr[ei++] = adv();
                        else adv(); /* skip } */
                        if (ei >= MAX_TOKEN_LEN - 1) break;
                    }
                    expr[ei] = '\0';
                    addTok(TOK_IDENT, expr); /* Store expr as identifier for now */
                    bi = 0;
                } else if (peek(0) == '\\') {
                    adv();
                    char e = adv();
                    if (e == 'n') buf[bi++] = '\n';
                    else if (e == 't') buf[bi++] = '\t';
                    else if (e == 'r') buf[bi++] = '\r';
                    else if (e == '\\') buf[bi++] = '\\';
                    else buf[bi++] = e;
                } else {
                    buf[bi++] = adv();
                }
                if (bi >= MAX_TOKEN_LEN - 1) break;
            }
            buf[bi] = '\0';
            if (peek(0) == quote) adv();
            if (bi > 0) addTok(TOK_FSTR, buf);
            continue;
        }

        /* Triple-quoted string """text""" */
        if (c == '"' && peek(1) == '"' && peek(2) == '"') {
            adv(); adv(); adv(); /* skip """ */
            char buf[MAX_TOKEN_LEN * 4];
            int bi = 0;
            while (peek(0) && !(peek(0) == '"' && peek(1) == '"' && peek(2) == '"')) {
                if (peek(0) == '\\') {
                    adv();
                    char e = adv();
                    if (e == 'n') buf[bi++] = '\n';
                    else if (e == 't') buf[bi++] = '\t';
                    else if (e == 'r') buf[bi++] = '\r';
                    else if (e == '\\') buf[bi++] = '\\';
                    else buf[bi++] = e;
                } else {
                    buf[bi++] = adv();
                }
                if (bi >= (int)(sizeof(buf) - 1)) break;
            }
            buf[bi] = '\0';
            if (peek(0) == '"') { adv(); adv(); adv(); }
            addTok(TOK_STR, buf);
            continue;
        }

        /* String */
        if (c == '"' || c == '\'') {
            char buf[MAX_TOKEN_LEN];
            int bi = 0;
            adv(); /* skip quote */
            while (peek(0) && peek(0) != c) {
                if (peek(0) == '\\') {
                    adv();
                    char e = adv();
                    if (e == 'n') buf[bi++] = '\n';
                    else if (e == 't') buf[bi++] = '\t';
                    else if (e == 'r') buf[bi++] = '\r';
                    else if (e == '\\') buf[bi++] = '\\';
                    else buf[bi++] = e;
                } else {
                    buf[bi++] = adv();
                }
                if (bi >= MAX_TOKEN_LEN - 1) break;
            }
            buf[bi] = '\0';
            if (peek(0) == c) adv();
            addTok(TOK_STR, buf);
            continue;
        }

        /* Number */
        if (isdigit(c)) {
            char buf[MAX_TOKEN_LEN];
            int bi = 0;
            while (isdigit(peek(0))) buf[bi++] = adv();
            if (peek(0) == '.' && isdigit(peek(1))) {
                buf[bi++] = adv();
                while (isdigit(peek(0))) buf[bi++] = adv();
            }
            buf[bi] = '\0';
            addTok(TOK_NUM, buf);
            continue;
        }

        /* Identifier/Keyword */
        if (isalpha(c) || c == '_') {
            char buf[MAX_TOKEN_LEN];
            int bi = 0;
            while (isalnum(peek(0)) || peek(0) == '_') buf[bi++] = adv();
            buf[bi] = '\0';
            TokenType t;
            if (isKW(buf, &t)) addTok(t, buf);
            else addTok(TOK_IDENT, buf);
            continue;
        }

        /* Multi-char operators */
        char t3[4] = {c, peek(1), peek(2), '\0'};
        char t2[3] = {c, peek(1), '\0'};

        if (strcmp(t3, "<->") == 0) { adv(); adv(); adv(); addTok(TOK_SWAP, "<->"); continue; }
        if (strcmp(t2, "=>") == 0) { adv(); adv(); addTok(TOK_ARROW, "=>"); continue; }
        if (strcmp(t2, "->") == 0) { adv(); adv(); addTok(TOK_ARROW, "->"); continue; }
        if (strcmp(t2, "|>") == 0) { adv(); adv(); addTok(TOK_PIPE, "|>"); continue; }
        if (strcmp(t2, "..") == 0) { adv(); adv(); addTok(TOK_DOTDOT, ".."); continue; }
        if (strcmp(t2, "==") == 0) { adv(); adv(); addTok(TOK_EQ, "=="); continue; }
        if (strcmp(t2, "!=") == 0) { adv(); adv(); addTok(TOK_NEQ, "!="); continue; }
        if (strcmp(t2, "<=") == 0) { adv(); adv(); addTok(TOK_LE, "<="); continue; }
        if (strcmp(t2, ">=") == 0) { adv(); adv(); addTok(TOK_GE, ">="); continue; }
        if (strcmp(t2, "**") == 0) { adv(); adv(); addTok(TOK_POW, "**"); continue; }
        if (strcmp(t2, "&&") == 0) { adv(); adv(); addTok(TOK_AND, "&&"); continue; }
        if (strcmp(t2, "||") == 0) { adv(); adv(); addTok(TOK_OR, "||"); continue; }
        if (strcmp(t2, "??") == 0) { adv(); adv(); addTok(TOK_NULL_COALESCE, "??"); continue; }
        if (strcmp(t2, "+=") == 0) { adv(); adv(); addTok(TOK_PLUS_EQ, "+="); continue; }
        if (strcmp(t2, "-=") == 0) { adv(); adv(); addTok(TOK_MIN_EQ, "-="); continue; }
        if (strcmp(t2, "*=") == 0) { adv(); adv(); addTok(TOK_MUL_EQ, "*="); continue; }
        if (strcmp(t2, "/=") == 0) { adv(); adv(); addTok(TOK_DIV_EQ, "/="); continue; }
        if (strcmp(t2, "++") == 0) { adv(); adv(); addTok(TOK_INC, "++"); continue; }
        if (strcmp(t2, "--") == 0) { adv(); adv(); addTok(TOK_DEC, "--"); continue; }

        /* Single char */
        switch (c) {
            case '+':
                adv();
                if (peek(0) == '+') { adv(); addTok(TOK_INC, "++"); }
                else addTok(TOK_PLUS, "+");
                break;
            case '-':
                adv();
                if (peek(0) == '-') { adv(); addTok(TOK_DEC, "--"); }
                else addTok(TOK_MIN, "-");
                break;
            case '?': adv(); addTok(TOK_QUESTION, "?"); break;
            case '*': adv(); addTok(TOK_MUL, "*"); break;
            case '/': adv(); addTok(TOK_DIV, "/"); break;
            case '%': adv(); addTok(TOK_MOD, "%"); break;
            case '<': adv(); addTok(TOK_LT, "<"); break;
            case '>': adv(); addTok(TOK_GT, ">"); break;
            case '=': adv(); addTok(TOK_ASSIGN, "="); break;
            case '!': adv(); addTok(TOK_BANG, "!"); break;
            case '(': adv(); addTok(TOK_LPAREN, "("); break;
            case ')': adv(); addTok(TOK_RPAREN, ")"); break;
            case '{': adv(); addTok(TOK_LBRACE, "{"); break;  /* Только для словарей */
            case '}': adv(); addTok(TOK_RBRACE, "}"); break;  /* Только для словарей */
            case '[': adv(); addTok(TOK_LBRACK, "["); break;
            case ']': adv(); addTok(TOK_RBRACK, "]"); break;
            case ',': adv(); addTok(TOK_COMMA, ","); break;
            case ':': adv(); addTok(TOK_COLON, ":"); break;
            case '.': adv(); addTok(TOK_DOT, "."); break;
            default:
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Lexer error [%d:%d]: unexpected char '%c'. Use indentation for blocks, not braces!", sl, sc, c);
                return;
        }
    }

    /* Закрываем все отступы в конце файла */
    while (indentDepth > 0) {
        indentDepth--;
        addTok(TOK_DEDENT, "");
    }

    Token* eof = &TOKENS[TCNT++];
    eof->type = TOK_EOF;
    eof->val[0] = '\0';
    eof->line = LINE;
    eof->col = COL;
}

/* ==================== RUNTIME VALUES ==================== */

typedef struct Val Val;
typedef struct Fn Fn;
typedef struct Macro Macro;
typedef struct ArrowFn ArrowFn;

/* Forward declare function pointer type for builtins */
typedef Val* (*BuiltinFn)(Val** args, int argc);

struct Fn {
    char* name;
    char** params;
    int pc;
    int bodyStart, bodyEnd; /* token indices */
    Token* moduleTokens; /* tokens from module file (NULL if main file) */
    int moduleTCnt; /* number of tokens in module */
};

struct Macro {
    char* name;
    char** params;
    int pc;
    int bodyStart, bodyEnd; /* token indices */
    Token* bodyTokens; /* tokens of macro body for expansion */
    int bodyTCnt; /* number of tokens in body */
};

struct ArrowFn {
    char** params;
    int pc;
    int bodyTokenStart;
    bool isExpr; /* true if body is single expression */
};

struct Val {
    enum { V_NUM, V_STR, V_BOOL, V_NULL, V_ARR, V_DICT, V_FN, V_ARROW, V_BUILTIN, V_MIRROR_FN, V_MACRO } type;
    union {
        double num;
        char* str;
        bool bol;
        struct { Val** items; int cnt; int cap; } arr;
        struct { char** keys; Val** vals; int cnt; int cap; } dict;
        Fn* fn;
        ArrowFn* arrow;
        struct { BuiltinFn fn; char* name; } builtin;
        Fn* mirrorFn; /* Mirror function - same structure as Fn */
        Macro* macro; /* Macro for compile-time expansion */
    } d;
};

/* Environment with parent chain for closures */
typedef struct Env {
    char* names[MAX_VARS];
    Val* vals[MAX_VARS];
    int cnt;
    struct Env* parent;
} Env;

static Env* GLOBAL = NULL;
static int IP = 0;
static char* CURRENT_FILE = NULL; /* Path to current file being executed */

/* Forward declaration */
static void evalBlock(int endToken, Env* env);
static void evalBlockReverse(Fn* mirrorFn, Env* env);

/* ==================== VALUE CREATION ==================== */

static Val* mkNum(double n) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_NUM;
    v->d.num = n;
    return v;
}

static Val* mkStr(const char* s) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_STR;
    v->d.str = strdup(s);
    return v;
}

static Val* mkBool(bool b) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_BOOL;
    v->d.bol = b;
    return v;
}

static Val* mkNull() {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_NULL;
    return v;
}

static Val* mkArr() {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_ARR;
    v->d.arr.cap = 16;
    v->d.arr.items = calloc(v->d.arr.cap, sizeof(Val*));
    return v;
}

static Val* mkDict() {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_DICT;
    v->d.dict.cap = 16;
    v->d.dict.keys = calloc(v->d.dict.cap, sizeof(char*));
    v->d.dict.vals = calloc(v->d.dict.cap, sizeof(Val*));
    return v;
}

static Val* mkFn(Fn* f) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_FN;
    v->d.fn = f;
    return v;
}

static Val* mkArrow(ArrowFn* a) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_ARROW;
    v->d.arrow = a;
    return v;
}

static Val* mkBuiltin(BuiltinFn fn, const char* name) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_BUILTIN;
    v->d.builtin.fn = fn;
    v->d.builtin.name = strdup(name);
    return v;
}

static Val* mkMirrorFn(Fn* f) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_MIRROR_FN;
    v->d.mirrorFn = f;
    return v;
}

static Val* mkMacro(Macro* m) {
    Val* v = calloc(1, sizeof(Val));
    v->type = V_MACRO;
    v->d.macro = m;
    return v;
}

static void arrPush(Val* arr, Val* v) {
    if (arr->type != V_ARR) return;
    if (arr->d.arr.cnt >= arr->d.arr.cap) {
        arr->d.arr.cap *= 2;
        arr->d.arr.items = realloc(arr->d.arr.items, arr->d.arr.cap * sizeof(Val*));
    }
    arr->d.arr.items[arr->d.arr.cnt++] = v;
}

static void dictSet(Val* dict, const char* key, Val* v) {
    if (dict->type != V_DICT) return;
    /* Check if key exists */
    for (int i = 0; i < dict->d.dict.cnt; i++) {
        if (strcmp(dict->d.dict.keys[i], key) == 0) {
            freeVal(dict->d.dict.vals[i]);
            dict->d.dict.vals[i] = v;
            return;
        }
    }
    /* Add new key */
    if (dict->d.dict.cnt >= dict->d.dict.cap) {
        dict->d.dict.cap *= 2;
        dict->d.dict.keys = realloc(dict->d.dict.keys, dict->d.dict.cap * sizeof(char*));
        dict->d.dict.vals = realloc(dict->d.dict.vals, dict->d.dict.cap * sizeof(Val*));
    }
    dict->d.dict.keys[dict->d.dict.cnt] = strdup(key);
    dict->d.dict.vals[dict->d.dict.cnt++] = v;
}

/* Clone a value (deep copy) */
static Val* cloneVal(Val* v) {
    if (!v) return mkNull();
    if (v->type == V_NUM) return mkNum(v->d.num);
    if (v->type == V_STR) return mkStr(v->d.str);
    if (v->type == V_BOOL) return mkBool(v->d.bol);
    if (v->type == V_NULL) return mkNull();
    /* For arrays - deep copy */
    if (v->type == V_ARR) {
        Val* arr = mkArr();
        for (int i = 0; i < v->d.arr.cnt; i++) {
            arrPush(arr, cloneVal(v->d.arr.items[i]));
        }
        return arr;
    }
    /* For dicts - deep copy */
    if (v->type == V_DICT) {
        Val* dict = mkDict();
        for (int i = 0; i < v->d.dict.cnt; i++) {
            dictSet(dict, v->d.dict.keys[i], cloneVal(v->d.dict.vals[i]));
        }
        return dict;
    }
    /* For functions and builtins - return null (cannot clone) */
    return mkNull();
}

static void freeVal(Val* v) {
    if (!v) return;
    switch (v->type) {
        case V_STR: free(v->d.str); break;
        case V_ARR:
            for (int i = 0; i < v->d.arr.cnt; i++) freeVal(v->d.arr.items[i]);
            free(v->d.arr.items);
            break;
        case V_DICT:
            for (int i = 0; i < v->d.dict.cnt; i++) {
                free(v->d.dict.keys[i]);
                freeVal(v->d.dict.vals[i]);
            }
            free(v->d.dict.keys);
            free(v->d.dict.vals);
            break;
        case V_FN:
            free(v->d.fn->name);
            for (int i = 0; i < v->d.fn->pc; i++) free(v->d.fn->params[i]);
            free(v->d.fn->params);
            if (v->d.fn->moduleTokens) free(v->d.fn->moduleTokens);
            free(v->d.fn);
            break;
        case V_MIRROR_FN:
            free(v->d.mirrorFn->name);
            for (int i = 0; i < v->d.mirrorFn->pc; i++) free(v->d.mirrorFn->params[i]);
            free(v->d.mirrorFn->params);
            if (v->d.mirrorFn->moduleTokens) free(v->d.mirrorFn->moduleTokens);
            free(v->d.mirrorFn);
            break;
        case V_ARROW:
            for (int i = 0; i < v->d.arrow->pc; i++) free(v->d.arrow->params[i]);
            free(v->d.arrow->params);
            free(v->d.arrow);
            break;
        case V_BUILTIN:
            free(v->d.builtin.name);
            break;
        case V_MACRO:
            free(v->d.macro->name);
            for (int i = 0; i < v->d.macro->pc; i++) free(v->d.macro->params[i]);
            free(v->d.macro->params);
            if (v->d.macro->bodyTokens) free(v->d.macro->bodyTokens);
            free(v->d.macro);
            break;
        default: break;
    }
    free(v);
}

static char* valStr(Val* v) {
    static char buf[MAX_LINE];
    if (!v) { buf[0] = '\0'; return buf; }
    switch (v->type) {
        case V_NUM:
            if (v->d.num == (long long)v->d.num) 
                snprintf(buf, sizeof(buf), "%lld", (long long)v->d.num);
            else 
                snprintf(buf, sizeof(buf), "%g", v->d.num);
            break;
        case V_STR: strcpy(buf, v->d.str); break;
        case V_BOOL: strcpy(buf, v->d.bol ? "true" : "false"); break;
        case V_NULL: strcpy(buf, "null"); break;
        case V_ARR: {
            char* p = buf; *p++ = '[';
            for (int i = 0; i < v->d.arr.cnt; i++) {
                if (i > 0) { *p++ = ','; *p++ = ' '; }
                Val* item = v->d.arr.items[i];
                /* Inline conversion to avoid static buffer overwrite */
                if (item->type == V_NUM) {
                    if (item->d.num == (long long)item->d.num)
                        p += sprintf(p, "%lld", (long long)item->d.num);
                    else
                        p += sprintf(p, "%g", item->d.num);
                } else if (item->type == V_STR) {
                    p += sprintf(p, "%s", item->d.str);
                } else if (item->type == V_BOOL) {
                    p += sprintf(p, "%s", item->d.bol ? "true" : "false");
                } else if (item->type == V_NULL) {
                    p += sprintf(p, "null");
                } else if (item->type == V_ARR) {
                    p += sprintf(p, "[...]");
                } else if (item->type == V_DICT) {
                    p += sprintf(p, "{...}");
                } else {
                    p += sprintf(p, "<fn>");
                }
            }
            *p++ = ']'; *p = '\0';
            break;
        }
        case V_DICT: {
            char* p = buf; *p++ = '{';
            for (int i = 0; i < v->d.dict.cnt; i++) {
                if (i > 0) { *p++ = ','; *p++ = ' '; }
                /* Add key */
                p += sprintf(p, "%s", v->d.dict.keys[i]);
                *p++ = ':'; *p++ = ' ';
                /* Add value inline */
                Val* val = v->d.dict.vals[i];
                if (val->type == V_NUM) {
                    if (val->d.num == (long long)val->d.num)
                        p += sprintf(p, "%lld", (long long)val->d.num);
                    else
                        p += sprintf(p, "%g", val->d.num);
                } else if (val->type == V_STR) {
                    p += sprintf(p, "%s", val->d.str);
                } else if (val->type == V_BOOL) {
                    p += sprintf(p, "%s", val->d.bol ? "true" : "false");
                } else if (val->type == V_NULL) {
                    p += sprintf(p, "null");
                } else if (val->type == V_ARR) {
                    p += sprintf(p, "[...]");
                } else if (val->type == V_DICT) {
                    p += sprintf(p, "{...}");
                } else {
                    p += sprintf(p, "<fn>");
                }
            }
            *p++ = '}'; *p = '\0';
            break;
        }
        case V_FN:
        case V_MIRROR_FN:
        case V_MACRO:
        case V_ARROW:
            strcpy(buf, "<fn>");
            break;
        case V_BUILTIN:
            snprintf(buf, sizeof(buf), "<builtin: %s>", v->d.builtin.name);
            break;
    }
    return buf;
}

/* ==================== ENVIRONMENT ==================== */

static Env* envNew(Env* parent) {
    Env* e = calloc(1, sizeof(Env));
    e->parent = parent;
    return e;
}

static void envSet(Env* e, const char* n, Val* v) {
    for (int i = 0; i < e->cnt; i++)
        if (strcmp(e->names[i], n) == 0) { 
            freeVal(e->vals[i]); 
            e->vals[i] = v; 
            return; 
        }
    if (e->cnt >= MAX_VARS) return;
    e->names[e->cnt] = strdup(n);
    e->vals[e->cnt] = v;
    e->cnt++;
}

static Val* envGet(Env* e, const char* n) {
    while (e) {
        for (int i = 0; i < e->cnt; i++)
            if (strcmp(e->names[i], n) == 0) return e->vals[i];
        e = e->parent;
    }
    return NULL;
}

static void envFree(Env* e) {
    if (!e) return;
    for (int i = 0; i < e->cnt; i++) {
        free(e->names[i]);
        freeVal(e->vals[i]);
    }
    free(e);
}

/* ==================== BUILTIN FUNCTIONS ==================== */

static Val* builtin_len(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    Val* a = args[0];
    if (a->type == V_STR) return mkNum(strlen(a->d.str));
    if (a->type == V_ARR) return mkNum(a->d.arr.cnt);
    if (a->type == V_DICT) return mkNum(a->d.dict.cnt);
    return mkNum(0);
}

static Val* builtin_str(Val** args, int argc) {
    if (argc < 1) return mkStr("");
    return mkStr(valStr(args[0]));
}

static Val* builtin_int(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    Val* a = args[0];
    if (a->type == V_NUM) return mkNum((long long)a->d.num);
    if (a->type == V_STR) return mkNum(atoi(a->d.str));
    return mkNum(0);
}

static Val* builtin_float(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    Val* a = args[0];
    if (a->type == V_NUM) return mkNum(a->d.num);
    if (a->type == V_STR) return mkNum(atof(a->d.str));
    return mkNum(0);
}

static Val* builtin_abs(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    if (args[0]->type != V_NUM) return mkNum(0);
    return mkNum(fabs(args[0]->d.num));
}

static Val* builtin_min(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    double m = args[0]->type == V_NUM ? args[0]->d.num : 1e308;
    if (args[0]->type == V_ARR) {
        Val* arr = args[0];
        for (int i = 0; i < arr->d.arr.cnt; i++) {
            if (arr->d.arr.items[i]->type == V_NUM) {
                double v = arr->d.arr.items[i]->d.num;
                if (v < m) m = v;
            }
        }
    } else {
        for (int i = 0; i < argc; i++) {
            if (args[i]->type == V_NUM && args[i]->d.num < m) m = args[i]->d.num;
        }
    }
    return mkNum(m);
}

static Val* builtin_max(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    double m = args[0]->type == V_NUM ? args[0]->d.num : -1e308;
    if (args[0]->type == V_ARR) {
        Val* arr = args[0];
        for (int i = 0; i < arr->d.arr.cnt; i++) {
            if (arr->d.arr.items[i]->type == V_NUM) {
                double v = arr->d.arr.items[i]->d.num;
                if (v > m) m = v;
            }
        }
    } else {
        for (int i = 0; i < argc; i++) {
            if (args[i]->type == V_NUM && args[i]->d.num > m) m = args[i]->d.num;
        }
    }
    return mkNum(m);
}

static Val* builtin_sum(Val** args, int argc) {
    if (argc < 1) return mkNum(0);
    double s = 0;
    if (args[0]->type == V_ARR) {
        Val* arr = args[0];
        for (int i = 0; i < arr->d.arr.cnt; i++) {
            if (arr->d.arr.items[i]->type == V_NUM)
                s += arr->d.arr.items[i]->d.num;
        }
    }
    return mkNum(s);
}

static Val* builtin_range(Val** args, int argc) {
    Val* arr = mkArr();
    if (argc == 1 && args[0]->type == V_NUM) {
        int n = (int)args[0]->d.num;
        for (int i = 0; i < n; i++) arrPush(arr, mkNum(i));
    } else if (argc >= 2 && args[0]->type == V_NUM && args[1]->type == V_NUM) {
        int start = (int)args[0]->d.num;
        int end = (int)args[1]->d.num;
        for (int i = start; i < end; i++) arrPush(arr, mkNum(i));
    }
    return arr;
}

static Val* builtin_append(Val** args, int argc) {
    if (argc < 2) return mkNull();
    if (args[0]->type == V_ARR) {
        /* Clone the item before adding to avoid double-free */
        arrPush(args[0], cloneVal(args[1]));
        return mkNull();
    }
    return mkNull();
}

static Val* builtin_pop(Val** args, int argc) {
    if (argc < 1) return mkNull();
    if (args[0]->type == V_ARR && args[0]->d.arr.cnt > 0) {
        Val* item = args[0]->d.arr.items[--args[0]->d.arr.cnt];
        /* Clone the item to avoid double-free */
        if (item->type == V_NUM) return mkNum(item->d.num);
        if (item->type == V_STR) return mkStr(item->d.str);
        if (item->type == V_BOOL) return mkBool(item->d.bol);
        return item; /* reference for complex types */
    }
    return mkNull();
}

static Val* builtin_keys(Val** args, int argc) {
    Val* arr = mkArr();
    if (argc < 1 || args[0]->type != V_DICT) return arr;
    Val* d = args[0];
    for (int i = 0; i < d->d.dict.cnt; i++)
        arrPush(arr, mkStr(d->d.dict.keys[i]));
    return arr;
}

static Val* builtin_values(Val** args, int argc) {
    Val* arr = mkArr();
    if (argc < 1 || args[0]->type != V_DICT) return arr;
    Val* d = args[0];
    for (int i = 0; i < d->d.dict.cnt; i++) {
        arrPush(arr, cloneVal(d->d.dict.vals[i]));
    }
    return arr;
}

static Val* builtin_typeof(Val** args, int argc) {
    if (argc < 1) return mkStr("null");
    Val* a = args[0];
    switch (a->type) {
        case V_NUM: return mkStr("number");
        case V_STR: return mkStr("string");
        case V_BOOL: return mkStr("boolean");
        case V_NULL: return mkStr("null");
        case V_ARR: return mkStr("array");
        case V_DICT: return mkStr("dict");
        case V_FN:
        case V_MIRROR_FN:
        case V_ARROW:
        case V_BUILTIN: return mkStr("function");
        case V_MACRO: return mkStr("macro");
    }
    return mkStr("unknown");
}

static Val* builtin_input(Val** args, int argc) {
    char buf[MAX_LINE] = {0};
    if (argc > 0 && args[0]->type == V_STR) {
        printf("%s", args[0]->d.str);
        fflush(stdout);
    }
    if (fgets(buf, sizeof(buf), stdin)) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len-1] == '\n') buf[len-1] = '\0';
        return mkStr(buf);
    }
    return mkStr("");
}

/* ==================== STRING MODULE ==================== */

static Val* builtin_str_upper(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    char* s = strdup(args[0]->d.str);
    for (char* p = s; *p; p++) *p = toupper(*p);
    Val* r = mkStr(s);
    free(s);
    return r;
}

static Val* builtin_str_lower(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    char* s = strdup(args[0]->d.str);
    for (char* p = s; *p; p++) *p = tolower(*p);
    Val* r = mkStr(s);
    free(s);
    return r;
}

static Val* builtin_str_split(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkArr();
    Val* arr = mkArr();
    char* str = args[0]->d.str;
    char* delim = args[1]->d.str;
    char* token = strtok(str, delim);
    while (token) {
        arrPush(arr, mkStr(token));
        token = strtok(NULL, delim);
    }
    return arr;
}

static Val* builtin_str_join(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_ARR) return mkStr("");
    char* delim = args[0]->d.str;
    Val* arr = args[1];
    char buf[MAX_LINE * 4] = {0};
    for (int i = 0; i < arr->d.arr.cnt; i++) {
        if (i > 0) strncat(buf, delim, sizeof(buf) - strlen(buf) - 1);
        if (arr->d.arr.items[i]->type == V_STR)
            strncat(buf, arr->d.arr.items[i]->d.str, sizeof(buf) - strlen(buf) - 1);
        else
            strncat(buf, valStr(arr->d.arr.items[i]), sizeof(buf) - strlen(buf) - 1);
    }
    return mkStr(buf);
}

static Val* builtin_str_replace(Val** args, int argc) {
    if (argc < 3 || args[0]->type != V_STR || args[1]->type != V_STR || args[2]->type != V_STR)
        return mkStr("");
    char* str = args[0]->d.str;
    char* from = args[1]->d.str;
    char* to = args[2]->d.str;
    char buf[MAX_LINE * 4] = {0};
    char* p = strstr(str, from);
    char* last = str;
    while (p) {
        strncat(buf, last, sizeof(buf) - strlen(buf) - 1);
        strncat(buf, to, sizeof(buf) - strlen(buf) - 1);
        last = p + strlen(from);
        p = strstr(last, from);
    }
    strncat(buf, last, sizeof(buf) - strlen(buf) - 1);
    return mkStr(buf);
}

static Val* builtin_str_strip(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    char* s = args[0]->d.str;
    while (*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') s++;
    char* end = s + strlen(s) - 1;
    while (end > s && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r')) end--;
    *(end + 1) = '\0';
    return mkStr(s);
}

static Val* builtin_str_len(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNum(0);
    return mkNum(strlen(args[0]->d.str));
}

static Val* builtin_str_contains(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkBool(false);
    return mkBool(strstr(args[0]->d.str, args[1]->d.str) != NULL);
}

static Val* builtin_str_startswith(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkBool(false);
    return mkBool(strncmp(args[0]->d.str, args[1]->d.str, strlen(args[1]->d.str)) == 0);
}

static Val* builtin_str_endswith(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkBool(false);
    size_t len0 = strlen(args[0]->d.str);
    size_t len1 = strlen(args[1]->d.str);
    if (len1 > len0) return mkBool(false);
    return mkBool(strcmp(args[0]->d.str + len0 - len1, args[1]->d.str) == 0);
}

static Val* builtin_str_find(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkNum(-1);
    char* p = strstr(args[0]->d.str, args[1]->d.str);
    if (!p) return mkNum(-1);
    return mkNum(p - args[0]->d.str);
}

static Val* builtin_str_substr(Val** args, int argc) {
    if (argc < 3 || args[0]->type != V_STR || args[1]->type != V_NUM || args[2]->type != V_NUM)
        return mkStr("");
    char* str = args[0]->d.str;
    int start = (int)args[1]->d.num;
    int len = (int)args[2]->d.num;
    if (start < 0 || start >= (int)strlen(str)) return mkStr("");
    char buf[MAX_LINE] = {0};
    strncpy(buf, str + start, len);
    buf[len] = '\0';
    return mkStr(buf);
}

/* ==================== MATH MODULE ==================== */

static Val* builtin_math_sin(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(sin(args[0]->d.num));
}

static Val* builtin_math_cos(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(cos(args[0]->d.num));
}

static Val* builtin_math_tan(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(tan(args[0]->d.num));
}

static Val* builtin_math_asin(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(asin(args[0]->d.num));
}

static Val* builtin_math_acos(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(acos(args[0]->d.num));
}

static Val* builtin_math_atan(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(atan(args[0]->d.num));
}

static Val* builtin_math_sqrt(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(sqrt(args[0]->d.num));
}

static Val* builtin_math_log(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(log(args[0]->d.num));
}

static Val* builtin_math_log10(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(log10(args[0]->d.num));
}

static Val* builtin_math_exp(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(exp(args[0]->d.num));
}

static Val* builtin_math_pow(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_NUM || args[1]->type != V_NUM) return mkNum(0);
    return mkNum(pow(args[0]->d.num, args[1]->d.num));
}

static Val* builtin_math_floor(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(floor(args[0]->d.num));
}

static Val* builtin_math_ceil(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(ceil(args[0]->d.num));
}

static Val* builtin_math_round(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    return mkNum(round(args[0]->d.num));
}

static Val* builtin_math_sign(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    double n = args[0]->d.num;
    if (n > 0) return mkNum(1);
    if (n < 0) return mkNum(-1);
    return mkNum(0);
}

static Val* builtin_math_pi(Val** args, int argc) {
    (void)args; (void)argc;
    return mkNum(M_PI);
}

static Val* builtin_math_e(Val** args, int argc) {
    (void)args; (void)argc;
    return mkNum(M_E);
}

static Val* builtin_math_tau(Val** args, int argc) {
    (void)args; (void)argc;
    return mkNum(M_PI * 2);
}

/* ==================== FILE MODULE ==================== */

static Val* builtin_file_read(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    FILE* f = fopen(args[0]->d.str, "r");
    if (!f) return mkStr("");
    char* buf = NULL;
    size_t cap = 4096, len = 0;
    buf = malloc(cap);
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (len + 1 >= cap) { cap *= 2; buf = realloc(buf, cap); }
        buf[len++] = c;
    }
    buf[len] = '\0';
    fclose(f);
    Val* r = mkStr(buf);
    free(buf);
    return r;
}

static Val* builtin_file_write(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkNull();
    FILE* f = fopen(args[0]->d.str, "w");
    if (!f) return mkNull();
    fprintf(f, "%s", args[1]->d.str);
    fclose(f);
    return mkNull();
}

static Val* builtin_file_append(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkNull();
    FILE* f = fopen(args[0]->d.str, "a");
    if (!f) return mkNull();
    fprintf(f, "%s", args[1]->d.str);
    fclose(f);
    return mkNull();
}

static Val* builtin_file_exists(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkBool(false);
    FILE* f = fopen(args[0]->d.str, "r");
    if (f) { fclose(f); return mkBool(true); }
    return mkBool(false);
}

static Val* builtin_file_delete(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNull();
    remove(args[0]->d.str);
    return mkNull();
}

static Val* builtin_file_lines(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkArr();
    FILE* f = fopen(args[0]->d.str, "r");
    if (!f) return mkArr();
    Val* arr = mkArr();
    char buf[MAX_LINE] = {0};
    while (fgets(buf, sizeof(buf), f)) {
        size_t len = strlen(buf);
        if (len > 0 && buf[len-1] == '\n') buf[len-1] = '\0';
        arrPush(arr, mkStr(buf));
        buf[0] = '\0';
    }
    fclose(f);
    return arr;
}

/* ==================== OS MODULE ==================== */

#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

static Val* builtin_os_getenv(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNull();
    char* val = getenv(args[0]->d.str);
    if (!val) return mkNull();
    return mkStr(val);
}

static Val* builtin_os_setenv(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkNull();
    setenv(args[0]->d.str, args[1]->d.str, 1);
    return mkNull();
}

static Val* builtin_os_system(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNum(-1);
    return mkNum(system(args[0]->d.str));
}

static Val* builtin_os_exit(Val** args, int argc) {
    int code = 0;
    if (argc > 0 && args[0]->type == V_NUM) code = (int)args[0]->d.num;
    exit(code);
    return mkNull();
}

static Val* builtin_os_cwd(Val** args, int argc) {
    (void)args; (void)argc;
    char buf[MAX_LINE] = {0};
    if (getcwd(buf, sizeof(buf))) return mkStr(buf);
    return mkStr("");
}

static Val* builtin_os_mkdir(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNull();
    mkdir(args[0]->d.str, 0755);
    return mkNull();
}

static Val* builtin_os_rmdir(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNull();
    rmdir(args[0]->d.str);
    return mkNull();
}

static Val* builtin_os_isfile(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkBool(false);
    struct stat st;
    if (stat(args[0]->d.str, &st) != 0) return mkBool(false);
    return mkBool(S_ISREG(st.st_mode));
}

static Val* builtin_os_isdir(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkBool(false);
    struct stat st;
    if (stat(args[0]->d.str, &st) != 0) return mkBool(false);
    return mkBool(S_ISDIR(st.st_mode));
}

/* ==================== JSON MODULE ==================== */

/* Simple JSON parser - basic implementation */
static Val* parse_json_value(const char** p);

static Val* parse_json_string(const char** p) {
    (*p)++; /* skip opening quote */
    char buf[MAX_LINE] = {0};
    int bi = 0;
    while (**p && **p != '"') {
        if (**p == '\\' && *(*p + 1)) {
            (*p)++;
            switch (**p) {
                case 'n': buf[bi++] = '\n'; break;
                case 't': buf[bi++] = '\t'; break;
                case 'r': buf[bi++] = '\r'; break;
                case '"': buf[bi++] = '"'; break;
                case '\\': buf[bi++] = '\\'; break;
                default: buf[bi++] = **p; break;
            }
        } else {
            buf[bi++] = **p;
        }
        (*p)++;
        if (bi >= MAX_LINE - 1) break;
    }
    buf[bi] = '\0';
    if (**p == '"') (*p)++;
    return mkStr(buf);
}

static Val* parse_json_number(const char** p) {
    char buf[MAX_TOKEN_LEN] = {0};
    int bi = 0;
    while (isdigit(**p) || **p == '.' || **p == '-' || **p == '+' || **p == 'e' || **p == 'E') {
        buf[bi++] = **p;
        (*p)++;
        if (bi >= MAX_TOKEN_LEN - 1) break;
    }
    buf[bi] = '\0';
    return mkNum(atof(buf));
}

static Val* parse_json_array(const char** p) {
    (*p)++; /* skip [ */
    Val* arr = mkArr();
    while (**p && **p != ']') {
        while (**p == ' ' || **p == '\t' || **p == '\n' || **p == ',') (*p)++;
        if (**p == ']') break;
        Val* item = parse_json_value(p);
        if (item) arrPush(arr, item);
        while (**p == ' ' || **p == '\t' || **p == '\n') (*p)++;
    }
    if (**p == ']') (*p)++;
    return arr;
}

static Val* parse_json_object(const char** p) {
    (*p)++; /* skip { */
    Val* dict = mkDict();
    while (**p && **p != '}') {
        while (**p == ' ' || **p == '\t' || **p == '\n' || **p == ',') (*p)++;
        if (**p == '}') break;
        if (**p != '"') break;
        Val* key = parse_json_string(p);
        while (**p == ' ' || **p == '\t' || **p == '\n') (*p)++;
        if (**p == ':') (*p)++;
        while (**p == ' ' || **p == '\t' || **p == '\n') (*p)++;
        Val* val = parse_json_value(p);
        if (key->type == V_STR && val) {
            dictSet(dict, key->d.str, val);
        }
        freeVal(key);
        while (**p == ' ' || **p == '\t' || **p == '\n') (*p)++;
    }
    if (**p == '}') (*p)++;
    return dict;
}

static Val* parse_json_value(const char** p) {
    while (**p == ' ' || **p == '\t' || **p == '\n') (*p)++;
    if (**p == '"') return parse_json_string(p);
    if (**p == '[') return parse_json_array(p);
    if (**p == '{') return parse_json_object(p);
    if (**p == 't' && strncmp(*p, "true", 4) == 0) {
        *p += 4;
        return mkBool(true);
    }
    if (**p == 'f' && strncmp(*p, "false", 5) == 0) {
        *p += 5;
        return mkBool(false);
    }
    if (**p == 'n' && strncmp(*p, "null", 4) == 0) {
        *p += 4;
        return mkNull();
    }
    if (isdigit(**p) || **p == '-') return parse_json_number(p);
    return mkNull();
}

static void json_stringify(Val* v, char* buf, size_t* len, size_t max);

static void json_stringify_string(const char* s, char* buf, size_t* len, size_t max) {
    buf[(*len)++] = '"';
    for (const char* p = s; *p && *len < max - 2; p++) {
        switch (*p) {
            case '"': buf[(*len)++] = '\\'; buf[(*len)++] = '"'; break;
            case '\\': buf[(*len)++] = '\\'; buf[(*len)++] = '\\'; break;
            case '\n': buf[(*len)++] = '\\'; buf[(*len)++] = 'n'; break;
            case '\t': buf[(*len)++] = '\\'; buf[(*len)++] = 't'; break;
            case '\r': buf[(*len)++] = '\\'; buf[(*len)++] = 'r'; break;
            default: buf[(*len)++] = *p; break;
        }
    }
    buf[(*len)++] = '"';
}

static void json_stringify(Val* v, char* buf, size_t* len, size_t max) {
    if (!v || v->type == V_NULL) {
        strcpy(buf + *len, "null");
        *len += 4;
        return;
    }
    if (v->type == V_BOOL) {
        strcpy(buf + *len, v->d.bol ? "true" : "false");
        *len += v->d.bol ? 4 : 5;
        return;
    }
    if (v->type == V_NUM) {
        int n = sprintf(buf + *len, "%g", v->d.num);
        *len += n;
        return;
    }
    if (v->type == V_STR) {
        json_stringify_string(v->d.str, buf, len, max);
        return;
    }
    if (v->type == V_ARR) {
        buf[(*len)++] = '[';
        for (int i = 0; i < v->d.arr.cnt && *len < max - 2; i++) {
            if (i > 0) buf[(*len)++] = ',';
            json_stringify(v->d.arr.items[i], buf, len, max);
        }
        buf[(*len)++] = ']';
        return;
    }
    if (v->type == V_DICT) {
        buf[(*len)++] = '{';
        for (int i = 0; i < v->d.dict.cnt && *len < max - 2; i++) {
            if (i > 0) buf[(*len)++] = ',';
            json_stringify_string(v->d.dict.keys[i], buf, len, max);
            buf[(*len)++] = ':';
            json_stringify(v->d.dict.vals[i], buf, len, max);
        }
        buf[(*len)++] = '}';
        return;
    }
    strcpy(buf + *len, "null");
    *len += 4;
}

static Val* builtin_json_parse(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkNull();
    const char* p = args[0]->d.str;
    return parse_json_value(&p);
}

static Val* builtin_json_stringify(Val** args, int argc) {
    if (argc < 1) return mkStr("null");
    char buf[MAX_LINE * 4] = {0};
    size_t len = 0;
    json_stringify(args[0], buf, &len, sizeof(buf));
    return mkStr(buf);
}

/* ==================== DATETIME MODULE ==================== */

static Val* builtin_datetime_now(Val** args, int argc) {
    (void)args; (void)argc;
    return mkNum((double)time(NULL));
}

static Val* builtin_datetime_strftime(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_NUM || args[1]->type != V_STR) return mkStr("");
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    char buf[MAX_LINE] = {0};
    strftime(buf, sizeof(buf), args[1]->d.str, tm);
    return mkStr(buf);
}

static Val* builtin_datetime_strptime(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkNum(0);
    struct tm tm = {0};
    strptime(args[0]->d.str, args[1]->d.str, &tm);
    return mkNum((double)mktime(&tm));
}

static Val* builtin_datetime_year(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_year + 1900);
}

static Val* builtin_datetime_month(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_mon + 1);
}

static Val* builtin_datetime_day(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_mday);
}

static Val* builtin_datetime_hour(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_hour);
}

static Val* builtin_datetime_minute(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_min);
}

static Val* builtin_datetime_second(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNum(0);
    time_t t = (time_t)args[0]->d.num;
    struct tm* tm = localtime(&t);
    return mkNum(tm->tm_sec);
}

/* ==================== CRYPTO MODULE ==================== */

static Val* builtin_crypto_hash(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkStr("");
    
    const EVP_MD* md = NULL;
    if (strcmp(args[1]->d.str, "md5") == 0) md = EVP_md5();
    else if (strcmp(args[1]->d.str, "sha1") == 0) md = EVP_sha1();
    else if (strcmp(args[1]->d.str, "sha256") == 0) md = EVP_sha256();
    else if (strcmp(args[1]->d.str, "sha512") == 0) md = EVP_sha512();
    else return mkStr("");
    
    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len = 0;
    EVP_Digest(args[0]->d.str, strlen(args[0]->d.str), hash, &hash_len, md, NULL);
    
    char hex[EVP_MAX_MD_SIZE * 2 + 1] = {0};
    for (unsigned int i = 0; i < hash_len; i++) {
        sprintf(hex + i * 2, "%02x", hash[i]);
    }
    return mkStr(hex);
}

static Val* builtin_crypto_md5(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    
    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len = 0;
    EVP_Digest(args[0]->d.str, strlen(args[0]->d.str), hash, &hash_len, EVP_md5(), NULL);
    
    char hex[33] = {0};
    for (unsigned int i = 0; i < hash_len; i++) {
        sprintf(hex + i * 2, "%02x", hash[i]);
    }
    return mkStr(hex);
}

static Val* builtin_crypto_sha256(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_STR) return mkStr("");
    
    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len = 0;
    EVP_Digest(args[0]->d.str, strlen(args[0]->d.str), hash, &hash_len, EVP_sha256(), NULL);
    
    char hex[65] = {0};
    for (unsigned int i = 0; i < hash_len; i++) {
        sprintf(hex + i * 2, "%02x", hash[i]);
    }
    return mkStr(hex);
}

/* ==================== REGEX MODULE ==================== */

static Val* builtin_regex_match(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkBool(false);
    
    regex_t regex;
    int reti = regcomp(&regex, args[1]->d.str, REG_EXTENDED);
    if (reti) { regfree(&regex); return mkBool(false); }
    
    reti = regexec(&regex, args[0]->d.str, 0, NULL, 0);
    regfree(&regex);
    return mkBool(reti == 0);
}

static Val* builtin_regex_replace(Val** args, int argc) {
    if (argc < 3 || args[0]->type != V_STR || args[1]->type != V_STR || args[2]->type != V_STR)
        return mkStr("");
    
    /* Simple replacement - just return original for now */
    return mkStr(args[0]->d.str);
}

static Val* builtin_regex_split(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_STR || args[1]->type != V_STR) return mkArr();
    /* Use str_split for now */
    return builtin_str_split(args, argc);
}

/* ==================== RANDOM MODULE ==================== */

static int g_seeded = 0;

static Val* builtin_random(Val** args, int argc) {
    (void)args; (void)argc;
    if (!g_seeded) { srand(time(NULL)); g_seeded = 1; }
    return mkNum((double)rand() / RAND_MAX);
}

static Val* builtin_randint(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_NUM || args[1]->type != V_NUM) return mkNum(0);
    if (!g_seeded) { srand(time(NULL)); g_seeded = 1; }
    int lo = (int)args[0]->d.num;
    int hi = (int)args[1]->d.num;
    return mkNum(lo + rand() % (hi - lo + 1));
}

static Val* builtin_choice(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_ARR) return mkNull();
    if (!g_seeded) { srand(time(NULL)); g_seeded = 1; }
    Val* arr = args[0];
    if (arr->d.arr.cnt == 0) return mkNull();
    int idx = rand() % arr->d.arr.cnt;
    return cloneVal(arr->d.arr.items[idx]);
}

static Val* builtin_shuffle(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_ARR) return mkNull();
    if (!g_seeded) { srand(time(NULL)); g_seeded = 1; }
    Val* arr = args[0];
    for (int i = arr->d.arr.cnt - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        Val* tmp = arr->d.arr.items[i];
        arr->d.arr.items[i] = arr->d.arr.items[j];
        arr->d.arr.items[j] = tmp;
    }
    return mkNull();
}

/* ==================== TIME MODULE ==================== */

static Val* builtin_time(Val** args, int argc) {
    (void)args; (void)argc;
    return mkNum((double)time(NULL));
}

static Val* builtin_sleep(Val** args, int argc) {
    if (argc < 1 || args[0]->type != V_NUM) return mkNull();
    int ms = (int)args[0]->d.num;
    usleep(ms * 1000);
    return mkNull();
}

/* ==================== ARRAY MODULE ==================== */

static Val* builtin_array_map(Val** args, int argc) {
    /* Simplified: just returns the array - proper map needs closures */
    if (argc < 2 || args[0]->type != V_ARR) return mkArr();
    return cloneVal(args[0]);
}

static Val* builtin_array_filter(Val** args, int argc) {
    /* Simplified: just returns the array */
    if (argc < 2 || args[0]->type != V_ARR) return mkArr();
    return cloneVal(args[0]);
}

static Val* builtin_array_reduce(Val** args, int argc) {
    /* Simplified: returns first element or null */
    if (argc < 2 || args[0]->type != V_ARR) return mkNull();
    Val* arr = args[0];
    if (arr->d.arr.cnt == 0) return mkNull();
    return cloneVal(arr->d.arr.items[0]);
}

static Val* builtin_array_find(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_ARR || !args[1]) return mkNull();
    Val* arr = args[0];
    Val* target = args[1];
    for (int i = 0; i < arr->d.arr.cnt; i++) {
        Val* item = arr->d.arr.items[i];
        if (!item) continue;
        /* Compare by type and value */
        if (item->type == target->type) {
            if (item->type == V_NUM && item->d.num == target->d.num)
                return cloneVal(item);
            if (item->type == V_STR && strcmp(item->d.str, target->d.str) == 0)
                return cloneVal(item);
            if (item->type == V_BOOL && item->d.bol == target->d.bol)
                return cloneVal(item);
        }
    }
    return mkNull();
}

static Val* builtin_array_index(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_ARR || args[1]->type != V_NUM) return mkNum(-1);
    Val* arr = args[0];
    int idx = (int)args[1]->d.num;
    if (idx < 0 || idx >= arr->d.arr.cnt) return mkNum(-1);
    return mkNum(idx);
}

static Val* builtin_array_includes(Val** args, int argc) {
    if (argc < 2 || args[0]->type != V_ARR) return mkBool(false);
    Val* arr = args[0];
    for (int i = 0; i < arr->d.arr.cnt; i++) {
        if (arr->d.arr.items[i]->type == V_NUM && args[1]->type == V_NUM) {
            if (arr->d.arr.items[i]->d.num == args[1]->d.num) return mkBool(true);
        } else if (arr->d.arr.items[i]->type == V_STR && args[1]->type == V_STR) {
            if (strcmp(arr->d.arr.items[i]->d.str, args[1]->d.str) == 0) return mkBool(true);
        }
    }
    return mkBool(false);
}

static void setupBuiltins() {
    /* Core functions */
    envSet(GLOBAL, "len", mkBuiltin(builtin_len, "len"));
    envSet(GLOBAL, "str", mkBuiltin(builtin_str, "str"));
    envSet(GLOBAL, "int", mkBuiltin(builtin_int, "int"));
    envSet(GLOBAL, "float", mkBuiltin(builtin_float, "float"));
    envSet(GLOBAL, "abs", mkBuiltin(builtin_abs, "abs"));
    envSet(GLOBAL, "min", mkBuiltin(builtin_min, "min"));
    envSet(GLOBAL, "max", mkBuiltin(builtin_max, "max"));
    envSet(GLOBAL, "sum", mkBuiltin(builtin_sum, "sum"));
    envSet(GLOBAL, "range", mkBuiltin(builtin_range, "range"));
    envSet(GLOBAL, "append", mkBuiltin(builtin_append, "append"));
    envSet(GLOBAL, "pop", mkBuiltin(builtin_pop, "pop"));
    envSet(GLOBAL, "keys", mkBuiltin(builtin_keys, "keys"));
    envSet(GLOBAL, "values", mkBuiltin(builtin_values, "values"));
    envSet(GLOBAL, "typeof", mkBuiltin(builtin_typeof, "typeof"));
    envSet(GLOBAL, "input", mkBuiltin(builtin_input, "input"));

    /* String module */
    envSet(GLOBAL, "str_upper", mkBuiltin(builtin_str_upper, "str_upper"));
    envSet(GLOBAL, "str_lower", mkBuiltin(builtin_str_lower, "str_lower"));
    envSet(GLOBAL, "str_split", mkBuiltin(builtin_str_split, "str_split"));
    envSet(GLOBAL, "str_join", mkBuiltin(builtin_str_join, "str_join"));
    envSet(GLOBAL, "str_replace", mkBuiltin(builtin_str_replace, "str_replace"));
    envSet(GLOBAL, "str_strip", mkBuiltin(builtin_str_strip, "str_strip"));
    envSet(GLOBAL, "str_len", mkBuiltin(builtin_str_len, "str_len"));
    envSet(GLOBAL, "str_contains", mkBuiltin(builtin_str_contains, "str_contains"));
    envSet(GLOBAL, "str_startswith", mkBuiltin(builtin_str_startswith, "str_startswith"));
    envSet(GLOBAL, "str_endswith", mkBuiltin(builtin_str_endswith, "str_endswith"));
    envSet(GLOBAL, "str_find", mkBuiltin(builtin_str_find, "str_find"));
    envSet(GLOBAL, "str_substr", mkBuiltin(builtin_str_substr, "str_substr"));

    /* Math module */
    envSet(GLOBAL, "math_sin", mkBuiltin(builtin_math_sin, "math_sin"));
    envSet(GLOBAL, "math_cos", mkBuiltin(builtin_math_cos, "math_cos"));
    envSet(GLOBAL, "math_tan", mkBuiltin(builtin_math_tan, "math_tan"));
    envSet(GLOBAL, "math_asin", mkBuiltin(builtin_math_asin, "math_asin"));
    envSet(GLOBAL, "math_acos", mkBuiltin(builtin_math_acos, "math_acos"));
    envSet(GLOBAL, "math_atan", mkBuiltin(builtin_math_atan, "math_atan"));
    envSet(GLOBAL, "math_sqrt", mkBuiltin(builtin_math_sqrt, "math_sqrt"));
    envSet(GLOBAL, "math_log", mkBuiltin(builtin_math_log, "math_log"));
    envSet(GLOBAL, "math_log10", mkBuiltin(builtin_math_log10, "math_log10"));
    envSet(GLOBAL, "math_exp", mkBuiltin(builtin_math_exp, "math_exp"));
    envSet(GLOBAL, "math_pow", mkBuiltin(builtin_math_pow, "math_pow"));
    envSet(GLOBAL, "math_floor", mkBuiltin(builtin_math_floor, "math_floor"));
    envSet(GLOBAL, "math_ceil", mkBuiltin(builtin_math_ceil, "math_ceil"));
    envSet(GLOBAL, "math_round", mkBuiltin(builtin_math_round, "math_round"));
    envSet(GLOBAL, "math_sign", mkBuiltin(builtin_math_sign, "math_sign"));
    envSet(GLOBAL, "math_pi", mkBuiltin(builtin_math_pi, "math_pi"));
    envSet(GLOBAL, "math_e", mkBuiltin(builtin_math_e, "math_e"));
    envSet(GLOBAL, "math_tau", mkBuiltin(builtin_math_tau, "math_tau"));

    /* File module */
    envSet(GLOBAL, "file_read", mkBuiltin(builtin_file_read, "file_read"));
    envSet(GLOBAL, "file_write", mkBuiltin(builtin_file_write, "file_write"));
    envSet(GLOBAL, "file_append", mkBuiltin(builtin_file_append, "file_append"));
    envSet(GLOBAL, "file_exists", mkBuiltin(builtin_file_exists, "file_exists"));
    envSet(GLOBAL, "file_delete", mkBuiltin(builtin_file_delete, "file_delete"));
    envSet(GLOBAL, "file_lines", mkBuiltin(builtin_file_lines, "file_lines"));

    /* OS module */
    envSet(GLOBAL, "os_getenv", mkBuiltin(builtin_os_getenv, "os_getenv"));
    envSet(GLOBAL, "os_setenv", mkBuiltin(builtin_os_setenv, "os_setenv"));
    envSet(GLOBAL, "os_system", mkBuiltin(builtin_os_system, "os_system"));
    envSet(GLOBAL, "os_exit", mkBuiltin(builtin_os_exit, "os_exit"));
    envSet(GLOBAL, "os_cwd", mkBuiltin(builtin_os_cwd, "os_cwd"));
    envSet(GLOBAL, "os_mkdir", mkBuiltin(builtin_os_mkdir, "os_mkdir"));
    envSet(GLOBAL, "os_rmdir", mkBuiltin(builtin_os_rmdir, "os_rmdir"));
    envSet(GLOBAL, "os_isfile", mkBuiltin(builtin_os_isfile, "os_isfile"));
    envSet(GLOBAL, "os_isdir", mkBuiltin(builtin_os_isdir, "os_isdir"));

    /* JSON module */
    envSet(GLOBAL, "json_parse", mkBuiltin(builtin_json_parse, "json_parse"));
    envSet(GLOBAL, "json_stringify", mkBuiltin(builtin_json_stringify, "json_stringify"));

    /* Random module */
    envSet(GLOBAL, "random", mkBuiltin(builtin_random, "random"));
    envSet(GLOBAL, "randint", mkBuiltin(builtin_randint, "randint"));
    envSet(GLOBAL, "choice", mkBuiltin(builtin_choice, "choice"));
    envSet(GLOBAL, "shuffle", mkBuiltin(builtin_shuffle, "shuffle"));

    /* Time module */
    envSet(GLOBAL, "time", mkBuiltin(builtin_time, "time"));
    envSet(GLOBAL, "sleep", mkBuiltin(builtin_sleep, "sleep"));

    /* Array module */
    envSet(GLOBAL, "array_find", mkBuiltin(builtin_array_find, "array_find"));
    envSet(GLOBAL, "array_index", mkBuiltin(builtin_array_index, "array_index"));
    envSet(GLOBAL, "array_includes", mkBuiltin(builtin_array_includes, "array_includes"));
    envSet(GLOBAL, "array_map", mkBuiltin(builtin_array_map, "array_map"));
    envSet(GLOBAL, "array_filter", mkBuiltin(builtin_array_filter, "array_filter"));
    envSet(GLOBAL, "array_reduce", mkBuiltin(builtin_array_reduce, "array_reduce"));

    /* Datetime module */
    envSet(GLOBAL, "datetime_now", mkBuiltin(builtin_datetime_now, "datetime_now"));
    envSet(GLOBAL, "datetime_strftime", mkBuiltin(builtin_datetime_strftime, "datetime_strftime"));
    envSet(GLOBAL, "datetime_strptime", mkBuiltin(builtin_datetime_strptime, "datetime_strptime"));
    envSet(GLOBAL, "datetime_year", mkBuiltin(builtin_datetime_year, "datetime_year"));
    envSet(GLOBAL, "datetime_month", mkBuiltin(builtin_datetime_month, "datetime_month"));
    envSet(GLOBAL, "datetime_day", mkBuiltin(builtin_datetime_day, "datetime_day"));
    envSet(GLOBAL, "datetime_hour", mkBuiltin(builtin_datetime_hour, "datetime_hour"));
    envSet(GLOBAL, "datetime_minute", mkBuiltin(builtin_datetime_minute, "datetime_minute"));
    envSet(GLOBAL, "datetime_second", mkBuiltin(builtin_datetime_second, "datetime_second"));

    /* Crypto module */
    envSet(GLOBAL, "crypto_hash", mkBuiltin(builtin_crypto_hash, "crypto_hash"));
    envSet(GLOBAL, "crypto_md5", mkBuiltin(builtin_crypto_md5, "crypto_md5"));
    envSet(GLOBAL, "crypto_sha256", mkBuiltin(builtin_crypto_sha256, "crypto_sha256"));

    /* Regex module */
    envSet(GLOBAL, "regex_match", mkBuiltin(builtin_regex_match, "regex_match"));
    envSet(GLOBAL, "regex_replace", mkBuiltin(builtin_regex_replace, "regex_replace"));
    envSet(GLOBAL, "regex_split", mkBuiltin(builtin_regex_split, "regex_split"));

    /* Initialize exception variable */
    envSet(GLOBAL, "__exception__", mkNull());
}

/* ==================== MODULE IMPORT ==================== */

/* Load and execute a .mirr module file */
static void importModule(const char* moduleName) {
    char filePath[MAX_LINE * 2];

    /* Try to find module in same directory as current file */
    if (CURRENT_FILE) {
        /* Get directory of current file */
        char dirPath[MAX_LINE];
        strncpy(dirPath, CURRENT_FILE, sizeof(dirPath) - 1);
        dirPath[sizeof(dirPath) - 1] = '\0';

        /* Find last slash */
        char* lastSlash = strrchr(dirPath, '/');
        if (lastSlash) {
            *(lastSlash + 1) = '\0';
            snprintf(filePath, sizeof(filePath), "%s%s.mirr", dirPath, moduleName);
        } else {
            snprintf(filePath, sizeof(filePath), "%s.mirr", moduleName);
        }
    } else {
        snprintf(filePath, sizeof(filePath), "%s.mirr", moduleName);
    }

    /* Try to open the file */
    FILE* f = fopen(filePath, "r");
    if (!f) {
        /* Try without directory - current working directory */
        snprintf(filePath, sizeof(filePath), "%s.mirr", moduleName);
        f = fopen(filePath, "r");
    }

    if (!f) {
        snprintf(ERR_MSG, sizeof(ERR_MSG), "Module not found: %s", moduleName);
        return;
    }

    /* Read file content */
    char* src = NULL;
    size_t cap = 4096, len = 0;
    src = malloc(cap);

    int c;
    while ((c = fgetc(f)) != EOF) {
        if (len + 1 >= cap) { cap *= 2; src = realloc(src, cap); }
        src[len++] = c;
    }
    src[len] = '\0';
    fclose(f);

    /* Save current execution context */
    int savedIP = IP;
    int savedTCNT = TCNT;
    const char* savedSRC = SRC;
    int savedPOS = POS;
    int savedLINE = LINE;
    int savedCOL = COL;
    /* Copy tokens - add 1 for EOF token */
    int tokensToCopy = savedTCNT + 1;
    if (tokensToCopy > MAX_TOKENS) tokensToCopy = MAX_TOKENS;
    Token* savedTokens = NULL;
    if (tokensToCopy > 0) {
        savedTokens = malloc(sizeof(Token) * tokensToCopy);
        memcpy(savedTokens, TOKENS, sizeof(Token) * tokensToCopy);
    }

    /* Tokenize and execute module in global environment */
    SRC = src;
    POS = 0;
    LINE = 1;
    COL = 1;
    IP = 0;
    TCNT = 0;
    ERR_MSG[0] = '\0';

    tokenize();

    if (ERR_MSG[0]) {
        fprintf(stderr, "Module Error [%s]: %s\n", filePath, ERR_MSG);
        free(src);
        if (savedTokens) free(savedTokens);
        return;
    }

    evalBlock(TOK_EOF, NULL);

    if (ERR_MSG[0]) {
        fprintf(stderr, "Module Error [%s]: %s\n", filePath, ERR_MSG);
    }

    /* Restore previous execution context */
    IP = savedIP;
    TCNT = savedTCNT;
    SRC = savedSRC;
    POS = savedPOS;
    LINE = savedLINE;
    COL = savedCOL;
    if (savedTokens && tokensToCopy > 0) {
        memcpy(TOKENS, savedTokens, sizeof(Token) * tokensToCopy);
    }
    if (savedTokens) free(savedTokens);
    free(src);
}

/* ==================== PARSER & EVAL ==================== */

static Token* cur() { return (IP >= TCNT) ? &TOKENS[TCNT-1] : &TOKENS[IP]; }
static Token* peekT(int o) { int p = IP + o; return (p >= TCNT) ? &TOKENS[TCNT-1] : &TOKENS[p]; }
static Token* advT() { return &TOKENS[IP++]; }
static bool match(TokenType t) { return cur()->type == t; }
static void skipNL() { while (match(TOK_NL)) advT(); }

/* Forward declarations for recursive descent parser */
static Val* evalExpr();
static Val* evalPipe();
static Val* evalArrow();
static Val* evalLogicalOr();
static Val* evalLogicalAnd();
static Val* evalComparison();
static Val* evalAdd();
static Val* evalMul();
static Val* evalRange();
static Val* evalPower();
static Val* evalUnary();
static Val* evalPrimary();

/* Exception-like control flow */
static bool g_return = false;
static bool g_break = false;
static bool g_continue = false;
static bool g_throw = false; /* Exception thrown */
static Val* g_retVal = NULL;

static Val* evalExpr() {
    return evalPipe();
}

static Val* evalPipe() {
    Val* left = evalArrow();
    
    while (match(TOK_PIPE)) {
        advT(); /* |> */
        skipNL();
        
        /* Parse right side - could be function call or arrow */
        int savedIP = IP;
        
        /* Try to parse as function call: ident(...) */
        if (match(TOK_IDENT)) {
            char* name = strdup(cur()->val);
            advT();
            
            if (match(TOK_LPAREN)) {
                advT(); /* ( */
                Val* args[32];
                int ac = 0;
                args[ac++] = left; /* pipe value is first arg */
                
                while (!match(TOK_RPAREN) && !match(TOK_EOF) && ac < 32) {
                    args[ac++] = evalExpr();
                    if (match(TOK_COMMA)) advT();
                }
                if (match(TOK_RPAREN)) advT();
                
                /* Call function */
                Val* fn = envGet(GLOBAL, name);
                free(name);
                
                if (fn) {
                    if (fn->type == V_BUILTIN) {
                        Val* result = fn->d.builtin.fn(args, ac);
                        left = result;
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        continue;
                    } else if (fn->type == V_FN || fn->type == V_ARROW) {
                        /* Call user function */
                        Env* oldEnv = GLOBAL;
                        Env* newEnv = envNew(oldEnv);

                        if (fn->type == V_FN) {
                            Fn* f = fn->d.fn;
                            for (int i = 0; i < f->pc && i < ac; i++) {
                                /* Clone args for closure */
                                Val* arg = args[i];
                                Val* clone = NULL;
                                if (arg->type == V_NUM) clone = mkNum(arg->d.num);
                                else if (arg->type == V_STR) clone = mkStr(arg->d.str);
                                else if (arg->type == V_BOOL) clone = mkBool(arg->d.bol);
                                else if (arg->type == V_NULL) clone = mkNull();
                                else clone = arg;
                                envSet(newEnv, f->params[i], clone);
                            }
                            /* Save current tokens and switch to module tokens if needed */
                            Token* savedTokens = NULL;
                            int savedTCNT = TCNT;
                            if (f->moduleTokens) {
                                savedTokens = malloc(sizeof(Token) * (TCNT + 1));
                                memcpy(savedTokens, TOKENS, sizeof(Token) * (TCNT + 1));
                                memcpy(TOKENS, f->moduleTokens, sizeof(Token) * f->moduleTCnt);
                                TCNT = f->moduleTCnt - 1;
                            }
                            int savedIP2 = IP;
                            IP = f->bodyStart;
                            evalBlock(TOK_DEDENT, newEnv);
                            IP = savedIP2;
                            /* Restore tokens */
                            if (savedTokens) {
                                memcpy(TOKENS, savedTokens, sizeof(Token) * (savedTCNT + 1));
                                TCNT = savedTCNT;
                                free(savedTokens);
                            }
                        } else {
                            ArrowFn* a = fn->d.arrow;
                            for (int i = 0; i < a->pc && i < ac; i++) {
                                /* Clone args for closure */
                                Val* arg = args[i];
                                Val* clone = NULL;
                                if (arg->type == V_NUM) clone = mkNum(arg->d.num);
                                else if (arg->type == V_STR) clone = mkStr(arg->d.str);
                                else if (arg->type == V_BOOL) clone = mkBool(arg->d.bol);
                                else if (arg->type == V_NULL) clone = mkNull();
                                else clone = arg;
                                envSet(newEnv, a->params[i], clone);
                            }
                            if (a->isExpr) {
                                int savedIP2 = IP;
                                IP = a->bodyTokenStart;
                                Val* result = evalExpr();
                                IP = savedIP2;
                                left = result;
                            } else {
                                int savedIP2 = IP;
                                IP = a->bodyTokenStart;
                                evalBlock(TOK_DEDENT, newEnv);
                                IP = savedIP2;
                            }
                        }

                        if (g_return) {
                            left = g_retVal;
                            g_return = false;
                            g_retVal = NULL;
                        }

                        envFree(newEnv);
                        GLOBAL = oldEnv;
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        continue;
                    }
                }
                for (int i = 0; i < ac; i++) freeVal(args[i]);
                left = mkNull();
                continue;
            } else {
                /* Just identifier - pipe to function */
                IP = savedIP;
            }
            free(name);
        }
        
        /* Try arrow function */
        if (match(TOK_LPAREN) || match(TOK_IDENT)) {
            Val* arrowVal = evalArrow();
            if (arrowVal && arrowVal->type == V_ARROW) {
                Env* oldEnv = GLOBAL;
                Env* newEnv = envNew(oldEnv);
                ArrowFn* a = arrowVal->d.arrow;
                
                if (a->pc > 0) {
                    envSet(newEnv, a->params[0], left);
                }
                
                if (a->isExpr) {
                    int savedIP2 = IP;
                    IP = a->bodyTokenStart;
                    Val* result = evalExpr();
                    IP = savedIP2;
                    left = result;
                } else {
                    int savedIP2 = IP;
                    IP = a->bodyTokenStart;
                    evalBlock(TOK_DEDENT, newEnv);
                    IP = savedIP2;
                }
                
                if (g_return) {
                    left = g_retVal;
                    g_return = false;
                    g_retVal = NULL;
                }
                
                envFree(newEnv);
                GLOBAL = oldEnv;
                freeVal(arrowVal);
                continue;
            }
            freeVal(arrowVal);
        }
        
        IP = savedIP;
        break;
    }
    
    return left;
}

static Val* evalArrow() {
    /* Check for arrow function: (params) => expr or param => expr */
    if (match(TOK_LPAREN)) {
        int savedIP = IP;
        advT(); /* ( */
        
        char* params[MAX_PARAMS];
        int pc = 0;
        
        while (!match(TOK_RPAREN) && !match(TOK_EOF) && pc < MAX_PARAMS) {
            if (match(TOK_IDENT)) {
                params[pc++] = strdup(cur()->val);
                advT();
            } else {
                advT();
            }
            if (match(TOK_COMMA)) advT();
        }
        
        if (match(TOK_RPAREN) && peekT(1)->type == TOK_ARROW) {
            advT(); /* ) */
            advT(); /* => */
            
            ArrowFn* arrow = calloc(1, sizeof(ArrowFn));
            arrow->params = malloc(sizeof(char*) * pc);
            arrow->pc = pc;
            for (int i = 0; i < pc; i++) arrow->params[i] = params[i];
            arrow->bodyTokenStart = IP;
            arrow->isExpr = true;
            
            Val* body = evalExpr();
            freeVal(body);
            
            return mkArrow(arrow);
        }
        
        /* Not an arrow function, backtrack */
        IP = savedIP;
        for (int i = 0; i < pc; i++) free(params[i]);
    }
    
    /* Single param arrow: x => expr */
    if (match(TOK_IDENT)) {
        int savedIP = IP;
        char* paramName = strdup(cur()->val);
        advT();
        
        if (match(TOK_ARROW)) {
            advT(); /* => */
            
            ArrowFn* arrow = calloc(1, sizeof(ArrowFn));
            arrow->params = malloc(sizeof(char*));
            arrow->params[0] = paramName;
            arrow->pc = 1;
            arrow->bodyTokenStart = IP;
            arrow->isExpr = true;
            
            Val* body = evalExpr();
            freeVal(body);
            
            return mkArrow(arrow);
        }
        
        /* Not an arrow, backtrack */
        IP = savedIP;
        free(paramName);
    }
    
    return evalLogicalOr();
}

static Val* evalLogicalOr() {
    Val* left = evalLogicalAnd();

    /* Null coalescing: x ?? default */
    if (match(TOK_NULL_COALESCE)) {
        advT(); /* ?? */
        /* Check if left is null */
        if (left->type == V_NULL) {
            freeVal(left);
            left = evalLogicalAnd();
        } else {
            Val* right = evalLogicalAnd();
            freeVal(right);
        }
        return left;
    }

    /* Ternary operator: cond ? true_val : false_val */
    if (match(TOK_QUESTION)) {
        advT(); /* ? */
        bool isTrue = (left->type == V_BOOL && left->d.bol) ||
                      (left->type == V_NUM && left->d.num != 0) ||
                      (left->type == V_STR && left->d.str[0] != '\0');
        freeVal(left);

        Val* trueVal = evalExpr();
        if (!match(TOK_COLON)) {
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after ternary true expression");
            freeVal(trueVal);
            return mkNull();
        }
        advT(); /* : */
        Val* falseVal = evalExpr();

        return isTrue ? trueVal : falseVal;
    }

    while (match(TOK_OR)) {
        advT(); /* || */
        Val* right = evalLogicalAnd();

        bool lb = (left->type == V_BOOL && left->d.bol) ||
                  (left->type == V_NUM && left->d.num != 0) ||
                  (left->type == V_STR && left->d.str[0] != '\0');

        if (lb) {
            freeVal(right);
        } else {
            freeVal(left);
            left = right;
        }
    }

    return left;
}

static Val* evalLogicalAnd() {
    Val* left = evalComparison();
    
    while (match(TOK_AND)) {
        advT(); /* && */
        Val* right = evalComparison();
        
        bool lb = (left->type == V_BOOL && left->d.bol) || 
                  (left->type == V_NUM && left->d.num != 0) ||
                  (left->type == V_STR && left->d.str[0] != '\0');
        
        if (!lb) {
            freeVal(right);
        } else {
            freeVal(left);
            left = right;
        }
    }
    
    return left;
}

static Val* evalComparison() {
    Val* left = evalAdd();
    
    while (match(TOK_EQ) || match(TOK_NEQ) || match(TOK_LT) || 
           match(TOK_GT) || match(TOK_LE) || match(TOK_GE)) {
        TokenType op = cur()->type;
        advT();
        Val* right = evalAdd();
        
        bool result = false;
        
        if (left->type == V_NUM && right->type == V_NUM) {
            double l = left->d.num, r = right->d.num;
            switch (op) {
                case TOK_EQ: result = (l == r); break;
                case TOK_NEQ: result = (l != r); break;
                case TOK_LT: result = (l < r); break;
                case TOK_GT: result = (l > r); break;
                case TOK_LE: result = (l <= r); break;
                case TOK_GE: result = (l >= r); break;
                default: break;
            }
        } else if (left->type == V_STR && right->type == V_STR) {
            int cmp = strcmp(left->d.str, right->d.str);
            switch (op) {
                case TOK_EQ: result = (cmp == 0); break;
                case TOK_NEQ: result = (cmp != 0); break;
                case TOK_LT: result = (cmp < 0); break;
                case TOK_GT: result = (cmp > 0); break;
                case TOK_LE: result = (cmp <= 0); break;
                case TOK_GE: result = (cmp >= 0); break;
                default: break;
            }
        } else if (left->type == V_BOOL && right->type == V_BOOL) {
            switch (op) {
                case TOK_EQ: result = (left->d.bol == right->d.bol); break;
                case TOK_NEQ: result = (left->d.bol != right->d.bol); break;
                default: break;
            }
        } else {
            /* Different types */
            switch (op) {
                case TOK_EQ: result = false; break;
                case TOK_NEQ: result = true; break;
                default: break;
            }
        }
        
        freeVal(left);
        left = mkBool(result);
    }
    
    return left;
}

static Val* evalAdd() {
    Val* left = evalMul();

    while (match(TOK_PLUS) || match(TOK_MIN)) {
        TokenType op = cur()->type;
        advT();
        Val* right = evalMul();

        if (left->type == V_NUM && right->type == V_NUM) {
            if (op == TOK_PLUS)
                left->d.num = left->d.num + right->d.num;
            else
                left->d.num = left->d.num - right->d.num;
        } else if (left->type == V_STR || right->type == V_STR) {
            /* String concatenation */
            char buf[MAX_LINE * 2];
            char ls_tmp[MAX_LINE];
            char rs_tmp[MAX_LINE];
            /* Copy strings before freeing */
            if (left->type == V_STR) {
                strncpy(ls_tmp, left->d.str, sizeof(ls_tmp) - 1);
                ls_tmp[sizeof(ls_tmp) - 1] = '\0';
            } else {
                const char* ls = valStr(left);
                strncpy(ls_tmp, ls, sizeof(ls_tmp) - 1);
                ls_tmp[sizeof(ls_tmp) - 1] = '\0';
            }
            if (right->type == V_STR) {
                strncpy(rs_tmp, right->d.str, sizeof(rs_tmp) - 1);
                rs_tmp[sizeof(rs_tmp) - 1] = '\0';
            } else {
                const char* rs = valStr(right);
                strncpy(rs_tmp, rs, sizeof(rs_tmp) - 1);
                rs_tmp[sizeof(rs_tmp) - 1] = '\0';
            }
            freeVal(left);
            freeVal(right);
            snprintf(buf, sizeof(buf), "%s%s", ls_tmp, rs_tmp);
            left = mkStr(buf);
        } else {
            freeVal(right);
        }
    }

    return left;
}

static Val* evalMul() {
    Val* left = evalRange();

    while (match(TOK_MUL) || match(TOK_DIV) || match(TOK_MOD)) {
        TokenType op = cur()->type;
        advT();
        Val* right = evalRange();

        if (left->type == V_NUM && right->type == V_NUM) {
            if (op == TOK_MUL)
                left->d.num *= right->d.num;
            else if (op == TOK_DIV)
                left->d.num /= right->d.num;
            else if (op == TOK_MOD)
                left->d.num = fmod(left->d.num, right->d.num);
        }

        freeVal(right);
    }

    return left;
}

static Val* evalPower() {
    Val* left = evalUnary();

    if (match(TOK_POW)) {
        advT(); /* ** */
        Val* right = evalPower();

        if (left->type == V_NUM && right->type == V_NUM) {
            left->d.num = pow(left->d.num, right->d.num);
        }

        freeVal(right);
    }

    return left;
}

static Val* evalRange() {
    Val* left = evalPower();

    if (match(TOK_DOTDOT)) {
        advT(); /* .. */
        Val* right = evalPower();

        if (left->type == V_NUM && right->type == V_NUM) {
            /* Create range array */
            Val* arr = mkArr();
            int start = (int)left->d.num;
            int end = (int)right->d.num;
            for (int i = start; i < end; i++) {
                arrPush(arr, mkNum(i));
            }
            freeVal(left);
            freeVal(right);
            return arr;
        }

        freeVal(right);
    }

    return left;
}

static Val* evalUnary() {
    if (match(TOK_MIN)) {
        advT();
        Val* v = evalUnary();
        if (v->type == V_NUM) v->d.num = -v->d.num;
        return v;
    }
    
    if (match(TOK_NOT)) {
        advT();
        Val* v = evalUnary();
        bool b = (v->type == V_BOOL && v->d.bol) || 
                 (v->type == V_NUM && v->d.num != 0) ||
                 (v->type == V_STR && v->d.str[0] != '\0');
        freeVal(v);
        return mkBool(!b);
    }
    
    return evalPrimary();
}

static Val* evalPrimary() {
    if (match(TOK_NUM)) {
        double n = atof(cur()->val);
        advT();
        return mkNum(n);
    }

    if (match(TOK_STR)) {
        char* s = strdup(cur()->val);
        advT();
        return mkStr(s);
    }

    if (match(TOK_FSTR)) {
        /* f-string - interpolate variables */
        char* template = strdup(cur()->val);
        advT();
        /* For now, just return as regular string - interpolation requires more complex parsing */
        return mkStr(template);
    }

    if (match(TOK_BOOL)) {
        bool b = strcmp(cur()->val, "yes") == 0 || strcmp(cur()->val, "true") == 0;
        advT();
        return mkBool(b);
    }

    if (match(TOK_NULL)) {
        advT();
        return mkNull();
    }

    if (match(TOK_NIL)) {
        advT();
        return mkNull();
    }

    if (match(TOK_PRINT)) {
        advT(); /* print */
        /* Optional parentheses */
        if (match(TOK_LPAREN)) {
            advT(); /* ( */
            Val* v = evalExpr();
            if (match(TOK_RPAREN)) advT();
            printf("%s\n", valStr(v));
            fflush(stdout);
            freeVal(v);
            return mkNull();
        }
        /* No parentheses - print rest of line */
        Val* v = evalExpr();
        printf("%s\n", valStr(v));
        fflush(stdout);
        freeVal(v);
        return mkNull();
    }

    if (match(TOK_INPUT)) {
        advT(); /* input */
        /* Optional parentheses */
        if (match(TOK_LPAREN)) {
            advT();
            Val* prompt = evalExpr();
            if (match(TOK_RPAREN)) advT();
            Val* args[1] = {prompt};
            Val* result = builtin_input(args, 1);
            freeVal(prompt);
            return result;
        }
        return builtin_input(NULL, 0);
    }

    if (match(TOK_TYPEOF)) {
        advT(); /* typeof */
        if (!match(TOK_LPAREN)) {
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '(' after typeof");
            return mkNull();
        }
        advT(); /* ( */
        Val* v = evalExpr();
        if (!match(TOK_RPAREN)) {
            freeVal(v);
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after typeof argument");
            return mkNull();
        }
        advT(); /* ) */
        Val* args[1] = {v};
        Val* result = builtin_typeof(args, 1);
        freeVal(v);
        return result;
    }

    if (match(TOK_IDENT)) {
        char* name = strdup(cur()->val);
        advT();

        /* Check for macro call: name!(...) */
        bool isMacroCall = false;
        if (match(TOK_BANG)) {
            advT(); /* ! */
            isMacroCall = true;
        }

        /* Check for function call, index, or attribute access */
        while (true) {
            if (match(TOK_LPAREN)) {
                /* Function/Macro call */
                advT(); /* ( */
                Val* args[MAX_ARGS];
                int ac = 0;

                while (!match(TOK_RPAREN) && !match(TOK_EOF) && ac < MAX_ARGS) {
                    args[ac++] = evalExpr();
                    if (match(TOK_COMMA)) advT();
                }
                if (match(TOK_RPAREN)) advT();

                /* Get function/macro */
                Val* fn = envGet(GLOBAL, name);

                if (fn) {
                    /* Check for macro expansion */
                    if (isMacroCall && fn->type == V_MACRO) {
                        /* Macro expansion - execute body with bound args */
                        Macro* m = fn->d.macro;

                        /* Bind args to parameters */
                        Env* oldEnv = GLOBAL;
                        Env* newEnv = envNew(oldEnv);

                        for (int i = 0; i < m->pc && i < ac; i++) {
                            Val* argClone = cloneVal(args[i]);
                            envSet(newEnv, m->params[i], argClone);
                        }

                        /* Save tokens and switch to macro body tokens */
                        Token* savedTokens = NULL;
                        int savedTCNT = TCNT;
                        int savedIP = IP;

                        if (m->bodyTokens) {
                            savedTokens = malloc(sizeof(Token) * (TCNT + 1));
                            memcpy(savedTokens, TOKENS, sizeof(Token) * (TCNT + 1));
                            memcpy(TOKENS, m->bodyTokens, sizeof(Token) * m->bodyTCnt);
                            TCNT = m->bodyTCnt;
                        }

                        /* Execute macro body as a block */
                        IP = 0;
                        g_return = false;
                        evalBlock(TOK_EOF, newEnv);
                        IP = savedIP;

                        /* Get return value if any */
                        Val* result = NULL;
                        if (g_return) {
                            result = g_retVal;
                            g_return = false;
                            g_retVal = NULL;
                        }

                        /* Restore tokens */
                        if (savedTokens) {
                            memcpy(TOKENS, savedTokens, sizeof(Token) * (savedTCNT + 1));
                            TCNT = savedTCNT;
                            free(savedTokens);
                        }

                        envFree(newEnv);
                        GLOBAL = oldEnv;
                        free(name);
                        for (int i = 0; i < ac; i++) freeVal(args[i]);

                        return result ? result : mkNull();
                    }

                    if (fn->type == V_BUILTIN) {
                        Val* result = fn->d.builtin.fn(args, ac);
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        free(name);
                        return result;
                    } else if (fn->type == V_FN) {
                        Fn* f = fn->d.fn;
                        Env* oldEnv = GLOBAL;
                        Env* newEnv = envNew(oldEnv);

                        for (int i = 0; i < f->pc && i < ac; i++) {
                            /* Clone args for closure */
                            Val* arg = args[i];
                            Val* clone = NULL;
                            if (arg->type == V_NUM) clone = mkNum(arg->d.num);
                            else if (arg->type == V_STR) clone = mkStr(arg->d.str);
                            else if (arg->type == V_BOOL) clone = mkBool(arg->d.bol);
                            else if (arg->type == V_NULL) clone = mkNull();
                            else clone = arg; /* reference for arrays/dicts/fns */
                            envSet(newEnv, f->params[i], clone);
                        }

                        /* Save current tokens and switch to module tokens if needed */
                        Token* savedTokens = NULL;
                        int savedTCNT = TCNT;
                        if (f->moduleTokens) {
                            savedTokens = malloc(sizeof(Token) * (TCNT + 1));
                            memcpy(savedTokens, TOKENS, sizeof(Token) * (TCNT + 1));
                            memcpy(TOKENS, f->moduleTokens, sizeof(Token) * f->moduleTCnt);
                            TCNT = f->moduleTCnt - 1;
                        }
                        int savedIP = IP;
                        IP = f->bodyStart;
                        evalBlock(TOK_DEDENT, newEnv);
                        IP = savedIP;
                        /* Restore tokens */
                        if (savedTokens) {
                            memcpy(TOKENS, savedTokens, sizeof(Token) * (savedTCNT + 1));
                            TCNT = savedTCNT;
                            free(savedTokens);
                        }

                        Val* result = NULL;
                        if (g_return) {
                            result = g_retVal;
                            g_return = false;
                            g_retVal = NULL;
                        }

                        envFree(newEnv);
                        GLOBAL = oldEnv;
                        free(name);
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        return result ? result : mkNull();
                    } else if (fn->type == V_ARROW) {
                        ArrowFn* a = fn->d.arrow;
                        Env* oldEnv = GLOBAL;
                        Env* newEnv = envNew(oldEnv);

                        for (int i = 0; i < a->pc && i < ac; i++) {
                            /* Clone args for closure */
                            Val* arg = args[i];
                            Val* clone = NULL;
                            if (arg->type == V_NUM) clone = mkNum(arg->d.num);
                            else if (arg->type == V_STR) clone = mkStr(arg->d.str);
                            else if (arg->type == V_BOOL) clone = mkBool(arg->d.bol);
                            else if (arg->type == V_NULL) clone = mkNull();
                            else clone = arg; /* reference for arrays/dicts/fns */
                            envSet(newEnv, a->params[i], clone);
                        }

                        Val* result = NULL;
                        if (a->isExpr) {
                            int savedIP = IP;
                            IP = a->bodyTokenStart;
                            result = evalExpr();
                            IP = savedIP;
                        } else {
                            int savedIP = IP;
                            IP = a->bodyTokenStart;
                            evalBlock(TOK_DEDENT, newEnv);
                            IP = savedIP;
                            if (g_return) {
                                result = g_retVal;
                                g_return = false;
                                g_retVal = NULL;
                            }
                        }

                        envFree(newEnv);
                        GLOBAL = oldEnv;
                        free(name);
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        return result ? result : mkNull();
                    } else if (fn->type == V_MIRROR_FN) {
                        /* Mirror function - execute body in reverse order */
                        Fn* f = fn->d.mirrorFn;
                        Env* oldEnv = GLOBAL;
                        Env* newEnv = envNew(oldEnv);

                        for (int i = 0; i < f->pc && i < ac; i++) {
                            /* Clone args for closure */
                            Val* arg = args[i];
                            Val* clone = NULL;
                            if (arg->type == V_NUM) clone = mkNum(arg->d.num);
                            else if (arg->type == V_STR) clone = mkStr(arg->d.str);
                            else if (arg->type == V_BOOL) clone = mkBool(arg->d.bol);
                            else if (arg->type == V_NULL) clone = mkNull();
                            else clone = arg; /* reference for arrays/dicts/fns */
                            envSet(newEnv, f->params[i], clone);
                        }

                        /* Execute body in reverse order */
                        evalBlockReverse(f, newEnv);

                        Val* result = NULL;
                        if (g_return) {
                            result = g_retVal;
                            g_return = false;
                            g_retVal = NULL;
                        }

                        envFree(newEnv);
                        GLOBAL = oldEnv;
                        free(name);
                        for (int i = 0; i < ac; i++) freeVal(args[i]);
                        return result ? result : mkNull();
                    }
                }

                /* Unknown function */
                for (int i = 0; i < ac; i++) freeVal(args[i]);
                free(name);
                return mkNull();
                
            } else if (match(TOK_LBRACK)) {
                /* Index access */
                advT(); /* [ */
                Val* index = evalExpr();
                if (!match(TOK_RBRACK)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ']' after index");
                    freeVal(index);
                    free(name);
                    return mkNull();
                }
                advT(); /* ] */
                
                /* Get the variable */
                Val* obj = envGet(GLOBAL, name);
                if (!obj) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Undefined variable: %s", name);
                    freeVal(index);
                    free(name);
                    return mkNull();
                }
                
                Val* result = mkNull();
                if (obj->type == V_ARR && index->type == V_NUM) {
                    int idx = (int)index->d.num;
                    if (idx >= 0 && idx < obj->d.arr.cnt) {
                        /* Return clone to avoid double-free */
                        Val* item = obj->d.arr.items[idx];
                        if (item->type == V_NUM) result = mkNum(item->d.num);
                        else if (item->type == V_STR) result = mkStr(item->d.str);
                        else if (item->type == V_BOOL) result = mkBool(item->d.bol);
                        else result = cloneVal(item);
                    }
                } else if (obj->type == V_DICT && index->type == V_STR) {
                    for (int i = 0; i < obj->d.dict.cnt; i++) {
                        if (strcmp(obj->d.dict.keys[i], index->d.str) == 0) {
                            result = cloneVal(obj->d.dict.vals[i]);
                            break;
                        }
                    }
                }

                freeVal(index);
                free(name);
                return result;
                
            } else if (match(TOK_DOT)) {
                /* Attribute access - for string methods */
                advT(); /* . */
                if (!match(TOK_IDENT)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected attribute name after '.'");
                    free(name);
                    return mkNull();
                }
                char* attr = strdup(cur()->val);
                advT();

                /* Get the variable */
                Val* obj = envGet(GLOBAL, name);
                if (!obj) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Undefined variable: %s", name);
                    free(attr);
                    free(name);
                    return mkNull();
                }

                /* Handle string methods */
                if (obj->type == V_STR) {
                    /* Check for method call with () */
                    if (match(TOK_LPAREN)) {
                        advT(); /* ( */
                        if (!match(TOK_RPAREN)) {
                            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after method call");
                            free(attr);
                            free(name);
                            return mkNull();
                        }
                        advT(); /* ) */

                        Val* result = mkNull();
                        if (strcmp(attr, "upper") == 0) {
                            char* s = strdup(obj->d.str);
                            for (char* p = s; *p; p++) *p = toupper(*p);
                            result = mkStr(s);
                            free(s);
                        } else if (strcmp(attr, "lower") == 0) {
                            char* s = strdup(obj->d.str);
                            for (char* p = s; *p; p++) *p = tolower(*p);
                            result = mkStr(s);
                            free(s);
                        }
                        free(attr);
                        free(name);
                        return result;
                    }
                }

                free(attr);
                free(name);
                return mkNull();
            } else {
                break;
            }
        }
        
        /* Simple variable access */
        Val* v = envGet(GLOBAL, name);
        free(name);

        if (v) {
            /* Return clone for all types to avoid double-free */
            return cloneVal(v);
        }

        return mkNull();
    }
    
    if (match(TOK_LPAREN)) {
        advT(); /* ( */
        Val* v = evalExpr();
        if (!match(TOK_RPAREN)) {
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after expression");
            return v;
        }
        advT(); /* ) */
        return v;
    }
    
    if (match(TOK_LBRACK)) {
        /* Array literal */
        advT(); /* [ */
        Val* arr = mkArr();
        skipNL();
        
        while (!match(TOK_RBRACK) && !match(TOK_EOF)) {
            Val* item = evalExpr();
            arrPush(arr, item);
            skipNL();
            if (match(TOK_COMMA)) advT();
            skipNL();
        }
        if (!match(TOK_RBRACK)) {
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ']' after array");
        } else {
            advT(); /* ] */
        }
        return arr;
    }
    
    if (match(TOK_LBRACE)) {
        /* Dict literal */
        advT(); /* { */
        Val* dict = mkDict();
        skipNL();
        
        while (!match(TOK_RBRACE) && !match(TOK_EOF)) {
            Val* key = evalExpr();
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after dict key");
                freeVal(key);
                break;
            }
            advT(); /* : */
            Val* val = evalExpr();
            
            dictSet(dict, valStr(key), val);
            freeVal(key);
            
            skipNL();
            if (match(TOK_COMMA)) advT();
            skipNL();
        }
        if (!match(TOK_RBRACE)) {
            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '}' after dict");
        } else {
            advT(); /* } */
        }
        return dict;
    }

    snprintf(ERR_MSG, sizeof(ERR_MSG), "Unexpected token: %.100s", cur()->val);
    return mkNull();
}

/* ==================== REVERSE BLOCK EVALUATION ==================== */

/* Execute block in reverse order - for mirror functions */
static void evalBlockReverse(Fn* mirrorFn, Env* env) {
    Env* oldEnv = GLOBAL;
    if (env) GLOBAL = env;

    /* Save current tokens */
    Token* savedTokens = NULL;
    int savedTCNT = TCNT;
    
    savedTokens = malloc(sizeof(Token) * (TCNT + 1));
    memcpy(savedTokens, TOKENS, sizeof(Token) * (TCNT + 1));
    
    /* Collect statements as arrays of tokens */
    typedef struct { 
        Token* tokens; 
        int count; 
    } StmtTokens;
    
    StmtTokens* stmts = malloc(sizeof(StmtTokens) * 256);
    int stmtCount = 0;
    
    int ip = 0;
    int depth = 0;
    
    /* Forward pass to collect statements */
    while (ip < mirrorFn->moduleTCnt && depth >= 0) {
        Token* t = &mirrorFn->moduleTokens[ip];
        
        if (t->type == TOK_INDENT) {
            depth++;
            ip++;
            continue;
        }
        if (t->type == TOK_DEDENT) {
            depth--;
            ip++;
            continue;
        }
        
        /* Skip leading NL tokens */
        if (t->type == TOK_NL) {
            ip++;
            continue;
        }
        
        /* Collect tokens until NL or end */
        Token* stmtTokArray = malloc(sizeof(Token) * 256);
        int stmtTokCount = 0;
        
        while (ip < mirrorFn->moduleTCnt) {
            Token* st = &mirrorFn->moduleTokens[ip];
            if (st->type == TOK_NL || st->type == TOK_DEDENT) break;
            if (st->type == TOK_INDENT) {
                ip++;
                continue;
            }
            if (stmtTokCount < 256) {
                stmtTokArray[stmtTokCount++] = *st;
            }
            ip++;
        }
        
        if (stmtTokCount > 0 && stmtCount < 256) {
            stmts[stmtCount].tokens = stmtTokArray;
            stmts[stmtCount].count = stmtTokCount;
            stmtCount++;
        } else if (stmtTokCount > 0) {
            free(stmtTokArray);
        }
    }
    
    /* Build reversed token array by concatenating statements in reverse */
    int totalTokens = 0;
    for (int i = 0; i < stmtCount; i++) {
        totalTokens += stmts[i].count + 1; /* +1 for NL */
    }
    
    Token* reversedTokens = malloc(sizeof(Token) * (totalTokens + 2)); /* +2 for NL and EOF */
    int revIdx = 0;
    
    /* Add statements in reverse order */
    for (int i = stmtCount - 1; i >= 0; i--) {
        for (int j = 0; j < stmts[i].count; j++) {
            reversedTokens[revIdx++] = stmts[i].tokens[j];
        }
        /* Add newline after each statement */
        reversedTokens[revIdx].type = TOK_NL;
        strcpy(reversedTokens[revIdx].val, "\\n");
        revIdx++;
        
        free(stmts[i].tokens);
    }
    
    /* Add EOF token */
    reversedTokens[revIdx].type = TOK_EOF;
    strcpy(reversedTokens[revIdx].val, "");
    revIdx++;
    totalTokens = revIdx;
    
    free(stmts);

    /* Execute reversed tokens */
    memcpy(TOKENS, reversedTokens, sizeof(Token) * totalTokens);
    TCNT = totalTokens;

    /* Now execute the reversed block */
    int savedIP = IP;
    IP = 0;
    evalBlock(TOK_EOF, env);
    IP = savedIP;

    /* Restore tokens */
    memcpy(TOKENS, savedTokens, sizeof(Token) * (savedTCNT + 1));
    TCNT = savedTCNT;
    
    /* Free reversed tokens after restoring */
    free(reversedTokens);
    free(savedTokens);

    if (env) GLOBAL = oldEnv;
}

/* ==================== BLOCK EVALUATION ==================== */

static void evalBlock(int endToken, Env* env) {
    Env* oldEnv = GLOBAL;
    if (env) GLOBAL = env;

    skipNL();
    while (!match(TOK_EOF) && (int)cur()->type != endToken) {
        skipNL();
        if (match(TOK_EOF) || (int)cur()->type == endToken) break;

        /* Check for control flow flags */
        if (g_break || g_return || g_continue || g_throw) break;

        if (match(TOK_IMPORT)) {
            advT(); /* import */

            if (!match(TOK_IDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected module name after 'import'");
                break;
            }
            char* moduleName = strdup(cur()->val);
            advT();

            /* Import the module */
            importModule(moduleName);
            free(moduleName);
            skipNL();

        } else if (match(TOK_LET)) {
            advT(); /* let */
            skipNL();
            
            /* Destructuring: let [x, y] = [...] or let {a, b} = {...} */
            if (match(TOK_LBRACK)) {
                advT(); /* [ */
                char* names[MAX_PARAMS];
                int nc = 0;
                
                while (!match(TOK_RBRACK) && !match(TOK_EOF) && nc < MAX_PARAMS) {
                    if (match(TOK_IDENT)) {
                        names[nc++] = strdup(cur()->val);
                        advT();
                    } else {
                        advT();
                    }
                    if (match(TOK_COMMA)) advT();
                    skipNL();
                }
                if (match(TOK_RBRACK)) advT();
                
                if (!match(TOK_ASSIGN)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '=' after destructuring");
                    for (int i = 0; i < nc; i++) free(names[i]);
                    break;
                }
                advT(); /* = */
                
                Val* v = evalExpr();
                
                /* Assign from array */
                if (v->type == V_ARR) {
                    for (int i = 0; i < nc && i < v->d.arr.cnt; i++) {
                        envSet(GLOBAL, names[i], cloneVal(v->d.arr.items[i]));
                    }
                }
                freeVal(v);
                for (int i = 0; i < nc; i++) free(names[i]);
                
            } else if (match(TOK_LBRACE)) {
                advT(); /* { */
                char* names[MAX_PARAMS];
                int nc = 0;
                
                while (!match(TOK_RBRACE) && !match(TOK_EOF) && nc < MAX_PARAMS) {
                    if (match(TOK_IDENT)) {
                        names[nc++] = strdup(cur()->val);
                        advT();
                    } else {
                        advT();
                    }
                    if (match(TOK_COMMA)) advT();
                    skipNL();
                }
                if (match(TOK_RBRACE)) advT();
                
                if (!match(TOK_ASSIGN)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '=' after destructuring");
                    for (int i = 0; i < nc; i++) free(names[i]);
                    break;
                }
                advT(); /* = */
                
                Val* v = evalExpr();
                
                /* Assign from dict */
                if (v->type == V_DICT) {
                    for (int i = 0; i < nc; i++) {
                        for (int j = 0; j < v->d.dict.cnt; j++) {
                            if (strcmp(v->d.dict.keys[j], names[i]) == 0) {
                                envSet(GLOBAL, names[i], cloneVal(v->d.dict.vals[j]));
                                break;
                            }
                        }
                    }
                }
                freeVal(v);
                for (int i = 0; i < nc; i++) free(names[i]);
                
            } else if (match(TOK_IDENT)) {
                char* name = strdup(cur()->val);
                advT();

                if (!match(TOK_ASSIGN)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '=' after variable name");
                    free(name);
                    break;
                }
                advT(); /* = */

                Val* v = evalExpr();
                envSet(GLOBAL, name, v);
                free(name);
            }

        } else if (match(TOK_FN)) {
            /* func name(p1, p2):
                 body
                 ret x
            */
            advT(); /* func */
            if (!match(TOK_IDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected function name");
                break;
            }
            char* fname = strdup(cur()->val);
            advT();

            if (!match(TOK_LPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '(' after function name");
                free(fname);
                break;
            }
            advT(); /* ( */

            char* params[MAX_PARAMS];
            int pc = 0;
            while (!match(TOK_RPAREN) && !match(TOK_EOF) && pc < MAX_PARAMS) {
                if (match(TOK_IDENT)) {
                    params[pc++] = strdup(cur()->val);
                    advT();
                } else {
                    advT();
                }
                if (match(TOK_COMMA)) advT();
            }
            if (!match(TOK_RPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after parameters");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* ) */

            /* Ожидаем ':' после параметров */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after function parameters");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела функции */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in function");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            int bodyStart = IP + 1;
            advT(); /* INDENT */

            /* Skip to matching DEDENT */
            int depth = 1;
            while (depth > 0 && !match(TOK_EOF)) {
                if (cur()->type == TOK_INDENT) depth++;
                else if (cur()->type == TOK_DEDENT) depth--;
                advT();
            }
            int bodyEnd = IP - 1;
            if (match(TOK_DEDENT)) advT();

            Fn* fn = calloc(1, sizeof(Fn));
            fn->name = fname;
            fn->params = malloc(sizeof(char*) * pc);
            fn->pc = pc;
            for (int i = 0; i < pc; i++) fn->params[i] = params[i];
            fn->bodyStart = bodyStart;
            fn->bodyEnd = bodyEnd;
            /* Save module tokens if we're in a module */
            if (CURRENT_FILE) {
                fn->moduleTokens = malloc(sizeof(Token) * (TCNT + 1));
                memcpy(fn->moduleTokens, TOKENS, sizeof(Token) * (TCNT + 1));
                fn->moduleTCnt = TCNT + 1;
            } else {
                fn->moduleTokens = NULL;
                fn->moduleTCnt = 0;
            }

            envSet(GLOBAL, fname, mkFn(fn));

        } else if (match(TOK_MIRFN)) {
            /* mirror-func name(p1, p2):
                 body
                 ret x
               Выполняется в обратном порядке!
            */
            advT(); /* mirror-func */
            if (!match(TOK_IDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected function name");
                break;
            }
            char* fname = strdup(cur()->val);
            advT();

            if (!match(TOK_LPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '(' after function name");
                free(fname);
                break;
            }
            advT(); /* ( */

            char* params[MAX_PARAMS];
            int pc = 0;
            while (!match(TOK_RPAREN) && !match(TOK_EOF) && pc < MAX_PARAMS) {
                if (match(TOK_IDENT)) {
                    params[pc++] = strdup(cur()->val);
                    advT();
                } else {
                    advT();
                }
                if (match(TOK_COMMA)) advT();
            }
            if (!match(TOK_RPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after parameters");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* ) */

            /* Ожидаем ':' после параметров */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after function parameters");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела функции */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in function");
                free(fname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* INDENT */
            
            /* Сохраняем позицию начала тела */
            int tokensStart = IP;

            /* Skip to matching DEDENT и сохраняем токены тела */
            int depth = 1;
            while (depth > 0 && !match(TOK_EOF)) {
                if (cur()->type == TOK_INDENT) depth++;
                else if (cur()->type == TOK_DEDENT) depth--;
                advT();
            }
            int tokensEnd = IP - 1;
            if (match(TOK_DEDENT)) advT();

            /* Создаем функцию с сохранением токенов тела */
            Fn* fn = calloc(1, sizeof(Fn));
            fn->name = fname;
            fn->params = malloc(sizeof(char*) * pc);
            fn->pc = pc;
            for (int i = 0; i < pc; i++) fn->params[i] = params[i];
            fn->bodyStart = tokensStart;
            fn->bodyEnd = tokensEnd;

            /* Сохраняем токены тела функции для обратного выполнения */
            int bodyTokenCount = tokensEnd - tokensStart + 1;
            if (bodyTokenCount > 0 && bodyTokenCount <= MAX_TOKENS) {
                fn->moduleTokens = malloc(sizeof(Token) * bodyTokenCount);
                memcpy(fn->moduleTokens, &TOKENS[tokensStart], sizeof(Token) * bodyTokenCount);
                fn->moduleTCnt = bodyTokenCount;
            } else {
                fn->moduleTokens = NULL;
                fn->moduleTCnt = 0;
            }

            envSet(GLOBAL, fname, mkMirrorFn(fn));

        } else if (match(TOK_MACRO)) {
            /* macro name(p1, p2):
                 body
                 ret код
               Разворачивается на этапе парсинга!
            */
            advT(); /* macro */
            if (!match(TOK_IDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected macro name");
                break;
            }
            char* mname = strdup(cur()->val);
            advT();

            if (!match(TOK_LPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected '(' after macro name");
                free(mname);
                break;
            }
            advT(); /* ( */

            char* params[MAX_PARAMS];
            int pc = 0;
            while (!match(TOK_RPAREN) && !match(TOK_EOF) && pc < MAX_PARAMS) {
                if (match(TOK_IDENT)) {
                    params[pc++] = strdup(cur()->val);
                    advT();
                } else {
                    advT();
                }
                if (match(TOK_COMMA)) advT();
            }
            if (!match(TOK_RPAREN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ')' after parameters");
                free(mname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* ) */

            /* Ожидаем ':' после параметров */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after macro parameters");
                free(mname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела макроса */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in macro");
                free(mname);
                for (int i = 0; i < pc; i++) free(params[i]);
                break;
            }
            advT(); /* INDENT */

            /* Сохраняем позицию начала тела */
            int tokensStart = IP;

            /* Skip to matching DEDENT и сохраняем токены тела */
            int depth = 1;
            while (depth > 0 && !match(TOK_EOF)) {
                if (cur()->type == TOK_INDENT) depth++;
                else if (cur()->type == TOK_DEDENT) depth--;
                advT();
            }
            int tokensEnd = IP - 1;
            if (match(TOK_DEDENT)) advT();

            /* Создаем макрос с сохранением токенов тела */
            Macro* macro = calloc(1, sizeof(Macro));
            macro->name = mname;
            macro->params = malloc(sizeof(char*) * pc);
            macro->pc = pc;
            for (int i = 0; i < pc; i++) macro->params[i] = params[i];
            macro->bodyStart = tokensStart;
            macro->bodyEnd = tokensEnd;

            /* Сохраняем токены тела макроса для развёртывания */
            int bodyTokenCount = tokensEnd - tokensStart + 1;
            if (bodyTokenCount > 0 && bodyTokenCount <= MAX_TOKENS) {
                macro->bodyTokens = malloc(sizeof(Token) * bodyTokenCount);
                memcpy(macro->bodyTokens, &TOKENS[tokensStart], sizeof(Token) * bodyTokenCount);
                macro->bodyTCnt = bodyTokenCount;
            } else {
                macro->bodyTokens = NULL;
                macro->bodyTCnt = 0;
            }

            envSet(GLOBAL, mname, mkMacro(macro));

        } else if (match(TOK_RET)) {
            advT(); /* return */

            Val* retVal = mkNull();
            if (!match(TOK_NL) && !match(TOK_DEDENT) && !match(TOK_EOF)) {
                retVal = evalExpr();
            }

            g_return = true;
            g_retVal = retVal;
            break;

        } else if (match(TOK_IF)) {
            advT(); /* if */
            Val* cond = evalExpr();

            bool isTrue = (cond->type == V_BOOL && cond->d.bol) ||
                          (cond->type == V_NUM && cond->d.num != 0) ||
                          (cond->type == V_STR && cond->d.str[0] != '\0');
            freeVal(cond);

            /* Ожидаем ':' после условия */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after if condition");
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела if */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in if statement");
                break;
            }
            advT(); /* INDENT */

            if (isTrue) {
                evalBlock(TOK_DEDENT, NULL);
                if (g_break || g_return) {
                    if (match(TOK_DEDENT)) advT();
                    break;
                }
            } else {
                /* Skip to DEDENT */
                int depth = 1;
                while (depth > 0 && !match(TOK_EOF)) {
                    if (cur()->type == TOK_INDENT) depth++;
                    else if (cur()->type == TOK_DEDENT) depth--;
                    advT();
                }
            }
            /* Проверка на break после if блока */
            if (g_break || g_return) break;
            if (match(TOK_DEDENT)) advT();

            /* Check for else */
            skipNL();
            if (match(TOK_ELSE)) {
                advT(); /* else */
                /* Ожидаем ':' после else */
                if (!match(TOK_COLON)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after else");
                    break;
                }
                advT(); /* : */
                skipNL();  /* Пропускаем newline после : */
                /* Ожидаем INDENT для тела else */
                if (!match(TOK_INDENT)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in else statement");
                    break;
                }
                advT(); /* INDENT */
                if (!isTrue) {
                    evalBlock(TOK_DEDENT, NULL);
                } else {
                    /* Skip else block */
                    int depth = 1;
                    while (depth > 0 && !match(TOK_EOF)) {
                        if (cur()->type == TOK_INDENT) depth++;
                        else if (cur()->type == TOK_DEDENT) depth--;
                        advT();
                    }
                }
                if (match(TOK_DEDENT)) advT();
                if (g_break || g_return) break;
            }

        } else if (match(TOK_MATCH)) {
            advT(); /* match */
            Val* matchVal = evalExpr();

            /* Ожидаем ':' после выражения */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after match expression");
                freeVal(matchVal);
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела match */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in match statement");
                freeVal(matchVal);
                break;
            }
            advT(); /* INDENT */

            bool matched = false;
            while (!match(TOK_DEDENT) && !match(TOK_EOF)) {
                skipNL();
                if (match(TOK_CASE)) {
                    advT(); /* case */
                    Val* caseVal = evalExpr();

                    /* Check if case matches */
                    bool caseMatch = false;
                    if (matchVal->type == V_NUM && caseVal->type == V_NUM) {
                        caseMatch = (matchVal->d.num == caseVal->d.num);
                    } else if (matchVal->type == V_STR && caseVal->type == V_STR) {
                        caseMatch = (strcmp(matchVal->d.str, caseVal->d.str) == 0);
                    } else if (matchVal->type == V_BOOL && caseVal->type == V_BOOL) {
                        caseMatch = (matchVal->d.bol == caseVal->d.bol);
                    }
                    freeVal(caseVal);

                    if (caseMatch && !matched) {
                        matched = true;
                        if (!match(TOK_COLON)) {
                            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after case value");
                            freeVal(matchVal);
                            break;
                        }
                        advT(); /* : */
                        skipNL();  /* Пропускаем newline после : */
                        if (match(TOK_INDENT)) {
                            advT();
                            evalBlock(TOK_DEDENT, NULL);
                            if (match(TOK_DEDENT)) advT();
                        } else if (!match(TOK_CASE) && !match(TOK_DEFAULT) && !match(TOK_DEDENT)) {
                            /* Single statement or expression */
                            Val* v = evalExpr();
                            freeVal(v);
                        }
                    } else {
                        if (!match(TOK_COLON)) {
                            snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after case value");
                            freeVal(matchVal);
                            break;
                        }
                        advT();
                        int depth = 1;
                        while (depth > 0 && !match(TOK_EOF)) {
                            if (cur()->type == TOK_INDENT) depth++;
                            else if (cur()->type == TOK_DEDENT) depth--;
                            else if ((cur()->type == TOK_CASE || cur()->type == TOK_DEFAULT) && depth == 1) break;
                            advT();
                        }
                    }
                } else if (match(TOK_DEFAULT)) {
                    advT();
                    if (!match(TOK_COLON)) {
                        snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after default");
                        freeVal(matchVal);
                        break;
                    }
                    advT();
                    skipNL();
                    if (!matched) {
                        if (match(TOK_INDENT)) {
                            advT();
                            evalBlock(TOK_DEDENT, NULL);
                            if (match(TOK_DEDENT)) advT();
                        }
                    } else {
                        int depth = 1;
                        while (depth > 0 && !match(TOK_EOF)) {
                            if (cur()->type == TOK_INDENT) depth++;
                            else if (cur()->type == TOK_DEDENT) depth--;
                            advT();
                        }
                    }
                    break;
                } else {
                    advT();
                }
            }
            if (match(TOK_DEDENT)) advT();
            freeVal(matchVal);

        } else if (match(TOK_TRY)) {
            advT(); /* try */

            /* Ожидаем ':' после try */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after try");
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела try */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in try statement");
                break;
            }
            advT(); /* INDENT */

            /* Execute try block */
            int savedBreak = g_break;
            int savedContinue = g_continue;
            int savedReturn = g_return;
            Val* savedRetVal = g_retVal;
            g_break = false;
            g_continue = false;
            g_return = false;
            g_throw = false;
            g_retVal = NULL;

            evalBlock(TOK_DEDENT, NULL);

            /* Check if exception was thrown */
            bool threw = g_throw;
            Val* throwVal = NULL;
            Val* excVal = envGet(GLOBAL, "__exception__");
            if (excVal && excVal->type != V_NULL) {
                throwVal = excVal; /* Don't clone - will be freed by envSet or us */
                envSet(GLOBAL, "__exception__", mkNull()); /* This frees old value */
            }

            g_throw = false;

            if (match(TOK_DEDENT)) advT();

            /* Handle catch */
            skipNL();
            if (match(TOK_CATCH)) {
                advT(); /* catch */

                /* Get exception variable name */
                char* excName = NULL;
                if (match(TOK_LPAREN)) {
                    advT();
                    if (match(TOK_IDENT)) {
                        excName = strdup(cur()->val);
                        advT();
                    }
                    if (match(TOK_RPAREN)) advT();
                }

                /* Ожидаем ':' после catch */
                if (!match(TOK_COLON)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after catch");
                    if (throwVal) freeVal(throwVal);
                    if (excName) free(excName);
                    g_break = savedBreak;
                    g_continue = savedContinue;
                    g_return = savedReturn;
                    g_retVal = savedRetVal;
                    break;
                }
                advT(); /* : */
                skipNL();  /* Пропускаем newline после : */

                /* Ожидаем INDENT для тела catch */
                if (!match(TOK_INDENT)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in catch statement");
                    if (throwVal) freeVal(throwVal);
                    if (excName) free(excName);
                    g_break = savedBreak;
                    g_continue = savedContinue;
                    g_return = savedReturn;
                    g_retVal = savedRetVal;
                    break;
                }
                advT(); /* INDENT */

                if (threw && throwVal) {
                    /* Set exception variable */
                    if (excName) {
                        envSet(GLOBAL, excName, throwVal);
                        free(excName);
                    } else {
                        freeVal(throwVal);
                        throwVal = NULL;
                    }

                    /* Reset throw state for catch block */
                    g_throw = false;
                    evalBlock(TOK_DEDENT, NULL);
                    if (match(TOK_DEDENT)) advT();

                    /* Restore state after catch */
                    g_break = savedBreak;
                    g_continue = savedContinue;
                    g_return = savedReturn;
                    g_retVal = savedRetVal;
                } else {
                    if (throwVal) { freeVal(throwVal); throwVal = NULL; }
                    if (excName) { free(excName); excName = NULL; }
                    /* Skip catch block */
                    int depth = 1;
                    while (depth > 0 && !match(TOK_EOF)) {
                        if (cur()->type == TOK_INDENT) depth++;
                        else if (cur()->type == TOK_DEDENT) depth--;
                        advT();
                    }
                }
            }

            /* Handle finally */
            skipNL();
            if (match(TOK_FINALLY)) {
                advT(); /* finally */
                /* Ожидаем ':' после finally */
                if (!match(TOK_COLON)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after finally");
                    g_break = savedBreak;
                    g_continue = savedContinue;
                    g_return = savedReturn;
                    g_retVal = savedRetVal;
                    break;
                }
                advT(); /* : */
                skipNL();  /* Пропускаем newline после : */
                /* Ожидаем INDENT для тела finally */
                if (!match(TOK_INDENT)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in finally statement");
                    g_break = savedBreak;
                    g_continue = savedContinue;
                    g_return = savedReturn;
                    g_retVal = savedRetVal;
                    break;
                }
                advT(); /* INDENT */
                evalBlock(TOK_DEDENT, NULL);
                if (match(TOK_DEDENT)) advT();
            }

            /* Restore state */
            g_break = savedBreak;
            g_continue = savedContinue;
            g_return = savedReturn;
            g_retVal = savedRetVal;

        } else if (match(TOK_WHILE)) {
            advT(); /* while */
            int condStart = IP;

            /* Ожидаем ':' после условия */
            if (!match(TOK_COLON)) {
                /* Если нет ':', пробуем вычислить условие и затем ищем ':' */
                Val* cond = evalExpr();
                freeVal(cond);

                if (!match(TOK_COLON)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after while condition");
                    break;
                }
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела while */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in while statement");
                break;
            }
            int bodyStart = IP + 1;
            int bodyEnd = IP + 1;  /* Будет обновлено */
            advT(); /* INDENT */

            /* Находим конец тела (DEDENT) */
            int depth = 1;
            int savedIP = IP;
            while (depth > 0 && !match(TOK_EOF)) {
                if (cur()->type == TOK_INDENT) depth++;
                else if (cur()->type == TOK_DEDENT) depth--;
                advT();
            }
            bodyEnd = IP;
            IP = savedIP;  /* Возвращаемся на начало тела */

            while (true) {
                IP = condStart;
                Val* cond = evalExpr();

                bool isTrue = (cond->type == V_BOOL && cond->d.bol) ||
                              (cond->type == V_NUM && cond->d.num != 0);
                freeVal(cond);

                if (!isTrue) break;

                IP = bodyStart;
                g_continue = false;
                evalBlock(TOK_DEDENT, NULL);

                if (g_break) {
                    g_break = false;
                    break;
                }

                if (match(TOK_DEDENT)) advT();
                skipNL();
            }

            /* Пропускаем тело цикла */
            IP = bodyEnd;
            if (match(TOK_DEDENT)) advT();

        } else if (match(TOK_FOR)) {
            advT(); /* for */
            if (!match(TOK_IDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected variable name after 'for'");
                break;
            }
            char* var = strdup(cur()->val);
            advT();

            if (!match(TOK_IN)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected 'in' after for variable");
                free(var);
                break;
            }
            advT(); /* in */

            Val* iterable = evalExpr();

            /* Ожидаем ':' после iterable */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after for iterable");
                free(var);
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела for */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in for statement");
                free(var);
                break;
            }
            int bodyStart = IP + 1;
            advT(); /* INDENT */

            /* Iterate */
            if (iterable->type == V_NUM) {
                int n = (int)iterable->d.num;
                for (int i = 0; i < n; i++) {
                    IP = bodyStart;
                    envSet(GLOBAL, var, mkNum(i));
                    g_continue = false;
                    evalBlock(TOK_DEDENT, NULL);
                    if (g_break) {
                        g_break = false;
                        break;
                    }
                }
            } else if (iterable->type == V_ARR) {
                for (int i = 0; i < iterable->d.arr.cnt; i++) {
                    IP = bodyStart;
                    Val* item = iterable->d.arr.items[i];
                    envSet(GLOBAL, var, item);
                    g_continue = false;
                    evalBlock(TOK_DEDENT, NULL);
                    if (g_break) {
                        g_break = false;
                        break;
                    }
                }
            }

            /* Skip past the loop body */
            if (match(TOK_DEDENT)) advT();

            free(var);
            /* Don't free iterable - items may be referenced in env */

        } else if (match(TOK_LOOP)) {
            advT(); /* loop */

            /* Ожидаем ':' после loop */
            if (!match(TOK_COLON)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected ':' after loop");
                break;
            }
            advT(); /* : */
            skipNL();  /* Пропускаем newline после : */

            /* Ожидаем INDENT для тела loop */
            if (!match(TOK_INDENT)) {
                snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected indentation after ':' in loop statement");
                break;
            }
            int bodyStart = IP + 1;
            int bodyEnd = IP + 1;
            advT(); /* INDENT */

            /* Находим конец тела (DEDENT) */
            int depth = 1;
            int savedIP = IP;
            while (depth > 0 && !match(TOK_EOF)) {
                if (cur()->type == TOK_INDENT) depth++;
                else if (cur()->type == TOK_DEDENT) depth--;
                advT();
            }
            bodyEnd = IP;
            IP = savedIP;  /* Возвращаемся на начало тела */

            while (true) {
                IP = bodyStart;
                g_continue = false;
                evalBlock(TOK_DEDENT, NULL);
                
                if (g_break) {
                    g_break = false;
                    break;
                }
                
                if (match(TOK_DEDENT)) advT();
                skipNL();
            }

            /* Пропускаем тело цикла */
            IP = bodyEnd;
            if (match(TOK_DEDENT)) advT();
            
        } else if (match(TOK_BRK) || match(TOK_STOP)) {
            advT(); /* break/stop */
            g_break = true;
            break;

        } else if (match(TOK_CONT) || match(TOK_NEXT)) {
            advT(); /* continue/next */
            g_continue = true;
            break;

        } else if (match(TOK_THROW)) {
            advT(); /* throw */
            Val* v = evalExpr();
            /* Set exception state */
            g_throw = true;
            envSet(GLOBAL, "__exception__", v);
            freeVal(v);
            /* Don't break - let evalBlock continue to check g_throw */

        } else if (match(TOK_IDENT)) {
            /* Expression statement or assignment */
            char* name = strdup(cur()->val);
            advT();

            /* Check for assignment or swap */
            if (match(TOK_ASSIGN)) {
                advT(); /* = */
                Val* v = evalExpr();
                envSet(GLOBAL, name, v);
                free(name);
            } else if (match(TOK_PLUS_EQ)) {
                advT(); /* += */
                Val* v = evalExpr();
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM && v->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num + v->d.num));
                }
                freeVal(v);
                free(name);
            } else if (match(TOK_MIN_EQ)) {
                advT(); /* -= */
                Val* v = evalExpr();
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM && v->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num - v->d.num));
                }
                freeVal(v);
                free(name);
            } else if (match(TOK_MUL_EQ)) {
                advT(); /* *= */
                Val* v = evalExpr();
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM && v->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num * v->d.num));
                }
                freeVal(v);
                free(name);
            } else if (match(TOK_DIV_EQ)) {
                advT(); /* /= */
                Val* v = evalExpr();
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM && v->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num / v->d.num));
                }
                freeVal(v);
                free(name);
            } else if (match(TOK_INC)) {
                advT(); /* ++ */
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num + 1));
                }
                free(name);
            } else if (match(TOK_DEC)) {
                advT(); /* -- */
                Val* cur = envGet(GLOBAL, name);
                if (cur && cur->type == V_NUM) {
                    envSet(GLOBAL, name, mkNum(cur->d.num - 1));
                }
                free(name);
            } else if (match(TOK_SWAP)) {
                advT(); /* <-> */
                /* Get right side identifier */
                if (!match(TOK_IDENT)) {
                    snprintf(ERR_MSG, sizeof(ERR_MSG), "Expected identifier after swap");
                    free(name);
                    break;
                }
                char* name2 = strdup(cur()->val);
                advT();

                /* Swap values */
                Val* v1 = envGet(GLOBAL, name);
                Val* v2 = envGet(GLOBAL, name2);

                if (v1 && v2) {
                    /* Clone values */
                    Val* c1 = NULL, *c2 = NULL;
                    if (v1->type == V_NUM) c1 = mkNum(v1->d.num);
                    else if (v1->type == V_STR) c1 = mkStr(v1->d.str);
                    else if (v1->type == V_BOOL) c1 = mkBool(v1->d.bol);
                    else c1 = v1;

                    if (v2->type == V_NUM) c2 = mkNum(v2->d.num);
                    else if (v2->type == V_STR) c2 = mkStr(v2->d.str);
                    else if (v2->type == V_BOOL) c2 = mkBool(v2->d.bol);
                    else c2 = v2;

                    envSet(GLOBAL, name, c2);
                    envSet(GLOBAL, name2, c1);
                }

                free(name);
                free(name2);
            } else {
                /* Expression statement - evaluate and discard */
                /* Backtrack and evaluate as expression */
                IP--;
                free(name);
                Val* v = evalExpr();
                freeVal(v);
            }
            
        } else {
            /* Expression statement */
            Val* v = evalExpr();
            freeVal(v);
        }
    }
    
    if (env) GLOBAL = oldEnv;
}

/* ==================== MAIN ==================== */

static void run(const char* src) {
    SRC = src;
    POS = 0;
    LINE = 1;
    COL = 1;
    TCNT = 0;
    IP = 0;
    ERR_MSG[0] = '\0';
    g_return = false;
    g_break = false;
    g_continue = false;
    g_retVal = NULL;

    if (GLOBAL) {
        envFree(GLOBAL);
    }
    GLOBAL = envNew(NULL);
    setupBuiltins();

    tokenize();

    if (ERR_MSG[0]) {
        fprintf(stderr, "Lexer Error: %s\n", ERR_MSG);
        return;
    }

    evalBlock(TOK_EOF, NULL);

    if (ERR_MSG[0]) {
        fprintf(stderr, "Runtime Error: %s\n", ERR_MSG);
    }

    /* Cleanup */
    envFree(GLOBAL);
    GLOBAL = NULL;
    CURRENT_FILE = NULL;
}

static void runFile(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "Error: File '%s' not found\n", path);
        exit(1);
    }

    char* src = NULL;
    size_t cap = 4096, len = 0;
    src = malloc(cap);

    int c;
    while ((c = fgetc(f)) != EOF) {
        if (len + 1 >= cap) { cap *= 2; src = realloc(src, cap); }
        src[len++] = c;
    }
    src[len] = '\0';
    fclose(f);

    /* Set current file path for module imports */
    CURRENT_FILE = strdup(path);
    run(src);
    free(CURRENT_FILE);
    CURRENT_FILE = NULL;
    free(src);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Mirror Language Interpreter (C) v1.0\n\n");
        printf("Usage: mirror [options] <file.mirror>\n");
        printf("       mirror --repl\n\n");
        printf("Options:\n");
        printf("  --repl    Start interactive REPL\n");
        printf("  --help    Show this help\n");
        return 0;
    }

    if (strcmp(argv[1], "--repl") == 0) {
        printf("Mirror Language REPL (C) v1.0\n");
        printf("Type 'exit' to quit\n\n");
        char line[MAX_LINE];
        while (1) {
            printf(">>> ");
            fflush(stdout);
            if (!fgets(line, sizeof(line), stdin)) break;
            line[strcspn(line, "\n")] = '\0';
            if (strcmp(line, "exit") == 0) break;
            if (strlen(line) == 0) continue;
            run(line);
            if (ERR_MSG[0]) fprintf(stderr, "Error: %s\n", ERR_MSG);
        }
        return 0;
    }

    if (strcmp(argv[1], "--help") == 0) {
        printf("Mirror Language Interpreter (C) v1.0\n\n");
        printf("Usage: mirror [options] <file.mirror>\n\n");
        printf("Options:\n");
        printf("  --repl    Start interactive REPL\n");
        printf("  --help    Show this help\n");
        return 0;
    }

    runFile(argv[1]);
    return 0;
}
