#!/usr/bin/env python3
"""
Mirror Language - Установщик с GUI на Qt6
Версия: 3.0
"""

import sys
import os
import subprocess
import shutil
from pathlib import Path

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QProgressBar, QStackedWidget, QRadioButton,
        QButtonGroup, QGroupBox, QTextEdit, QFrame, QCheckBox, QMessageBox,
        QFileDialog, QSystemTrayIcon, QMenu
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve
    from PyQt6.QtGui import QIcon, QFont, QPixmap, QPainter, QColor, QPalette, QLinearGradient
except ImportError:
    print("❌ PyQt6 не найден. Установите: pip install PyQt6")
    sys.exit(1)


# ============================================================================
# СТИЛИ (CSS)
# ============================================================================

STYLESHEET = """
/* Общие стили */
QMainWindow {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #1a1a2e, stop:0.5 #16213e, stop:1 #0f3460);
}

QWidget {
    font-family: 'Segoe UI', 'Ubuntu', sans-serif;
    color: #e0e0e0;
}

/* Заголовки */
QLabel#titleLabel {
    font-size: 32px;
    font-weight: bold;
    color: #00d9ff;
    padding: 20px;
}

QLabel#subtitleLabel {
    font-size: 16px;
    color: #a0a0a0;
    padding-bottom: 20px;
}

/* Кнопки */
QPushButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #00d9ff, stop:1 #0099cc);
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: bold;
    color: #000;
}

QPushButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #00ffff, stop:1 #00ccff);
}

QPushButton:pressed {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #0099cc, stop:1 #0077aa);
}

QPushButton:disabled {
    background: #444;
    color: #888;
}

QPushButton#secondaryBtn {
    background: transparent;
    border: 2px solid #00d9ff;
    color: #00d9ff;
}

QPushButton#secondaryBtn:hover {
    background: rgba(0, 217, 255, 0.1);
}

/* Радио кнопки */
QRadioButton {
    spacing: 10px;
    font-size: 14px;
    padding: 8px;
}

QRadioButton::indicator {
    width: 20px;
    height: 20px;
    border-radius: 10px;
    border: 2px solid #00d9ff;
    background: #1a1a2e;
}

QRadioButton::indicator:checked {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #00d9ff, stop:1 #0099cc);
}

/* Прогресс бар */
QProgressBar {
    border: none;
    border-radius: 8px;
    background: #2a2a4a;
    height: 20px;
    text-align: center;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #00d9ff, stop:1 #00ff88);
    border-radius: 8px;
}

/* Текстовое поле */
QTextEdit {
    background: #1a1a2e;
    border: 1px solid #333;
    border-radius: 8px;
    padding: 10px;
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 12px;
}

/* Группы */
QGroupBox {
    border: 2px solid #00d9ff;
    border-radius: 10px;
    margin-top: 15px;
    padding-top: 15px;
    font-weight: bold;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 15px;
    padding: 0 10px;
    color: #00d9ff;
}

/* Чекбоксы */
QCheckBox {
    spacing: 10px;
    font-size: 14px;
    padding: 5px;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border-radius: 4px;
    border: 2px solid #00d9ff;
    background: #1a1a2e;
}

QCheckBox::indicator:checked {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #00d9ff, stop:1 #00ff88);
}

/* Фреймы */
QFrame#cardFrame {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 15px;
    padding: 20px;
}

QFrame#line {
    background: #333;
    max-height: 2px;
}

/* Логотип */
QLabel#logoLabel {
    font-size: 64px;
    color: #00d9ff;
}
"""


# ============================================================================
# РАБОЧИЙ ПОТОК ДЛЯ УСТАНОВКИ
# ============================================================================

class InstallThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, script_dir, action, os_type):
        super().__init__()
        self.script_dir = script_dir
        self.action = action
        self.os_type = os_type
        
    def run(self):
        try:
            if self.action == "install":
                self.install()
            else:
                self.uninstall()
        except Exception as e:
            self.finished.emit(False, str(e))
    
    def install(self):
        """Установка Mirror Language"""
        self.progress.emit(10, "Компиляция интерпретатора...")
        
        # Компиляция
        try:
            result = subprocess.run(
                ["gcc", "-o", "mirror", "mirror.c", "-lm", "-lssl", "-lcrypto", "-O2"],
                cwd=self.script_dir,
                capture_output=True,
                text=True,
                timeout=60
            )
            if result.returncode != 0:
                raise Exception(f"Ошибка компиляции: {result.stderr}")
            self.progress.emit(40, "✅ Компиляция завершена")
        except subprocess.TimeoutExpired:
            raise Exception("Превышено время компиляции")
        
        self.progress.emit(50, "Установка в систему...")
        
        # Установка в /usr/local/bin или ~/.local/bin
        install_paths = ["/usr/local/bin", os.path.expanduser("~/.local/bin")]
        installed = False
        
        for path in install_paths:
            if os.path.exists(path) and os.access(path, os.W_OK):
                shutil.copy(os.path.join(self.script_dir, "mirror"), path)
                os.chmod(os.path.join(path, "mirror"), 0o755)
                installed = True
                self.progress.emit(80, f"✅ Установлено в {path}")
                break
        
        if not installed:
            # Копируем в текущую директорию
            self.progress.emit(80, "⚠️ Установка в локальную директорию")
        
        self.progress.emit(90, "Проверка установки...")
        
        # Проверка
        try:
            result = subprocess.run(
                [os.path.join(self.script_dir, "mirror"), "--help"],
                capture_output=True,
                timeout=5
            )
            if result.returncode == 0:
                self.progress.emit(100, "✅ Установка завершена успешно!")
                self.finished.emit(True, "Mirror Language установлен!")
            else:
                raise Exception("Проверка не пройдена")
        except:
            self.finished.emit(True, "Установлено (проверка недоступна)")
    
    def uninstall(self):
        """Удаление Mirror Language"""
        self.progress.emit(20, "Поиск установленных файлов...")
        
        # Удаление из системных путей
        install_paths = ["/usr/local/bin/mirror", os.path.expanduser("~/.local/bin/mirror")]
        removed = False
        
        for path in install_paths:
            if os.path.exists(path):
                os.remove(path)
                removed = True
                self.progress.emit(60, f"✅ Удалено из {path}")
        
        # Удаление локального бинарника
        local_mirror = os.path.join(self.script_dir, "mirror")
        if os.path.exists(local_mirror):
            os.remove(local_mirror)
            removed = True
            self.progress.emit(80, "✅ Локальный файл удалён")
        
        if removed:
            self.progress.emit(100, "✅ Удаление завершено!")
            self.finished.emit(True, "Mirror Language удалён!")
        else:
            self.finished.emit(True, "Ничего не найдено для удаления")


# ============================================================================
# СТРАНИЦЫ ИНТЕРФЕЙСА
# ============================================================================

class WelcomePage(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Логотип
        logo = QLabel("🪞")
        logo.setObjectName("logoLabel")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)
        
        # Заголовок
        title = QLabel("Mirror Language")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Подзаголовок
        subtitle = QLabel("Установщик с графическим интерфейсом")
        subtitle.setObjectName("subtitleLabel")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        layout.addSpacing(30)
        
        # Информация
        info_frame = QFrame()
        info_frame.setObjectName("cardFrame")
        info_layout = QVBoxLayout(info_frame)
        
        info_layout.addWidget(QLabel("📦 Версия: 3.0"))
        info_layout.addWidget(QLabel("🌐 Qt6 GUI Installer"))
        info_layout.addWidget(QLabel("🐧 Linux / macOS / Windows"))
        
        layout.addWidget(info_frame)
        
        layout.addSpacing(30)
        
        # Кнопка "Далее"
        next_btn = QPushButton("▶ Начать установку")
        next_btn.setFixedWidth(250)
        next_btn.clicked.emit()
        layout.addWidget(next_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.nextClicked = next_btn.clicked
        self.setLayout(layout)


class OSPage(QWidget):
    def __init__(self):
        super().__init__()
        self.selected_os = "Linux"
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Выберите операционную систему")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Группа с радио кнопками
        os_group = QGroupBox("Операционная система")
        os_layout = QVBoxLayout(os_group)
        
        self.os_buttons = QButtonGroup(self)
        
        # Определяем систему
        detected = self.detect_os()
        
        os_options = [
            ("Linux", "🐧 Linux"),
            ("macOS", "🍎 macOS"),
            ("Windows", "🪟 Windows")
        ]
        
        for os_id, os_text in os_options:
            rb = QRadioButton(os_text)
            if os_id == detected:
                rb.setChecked(True)
                self.selected_os = os_id
            rb.toggled.connect(lambda checked, oid=os_id: self.on_toggled(checked, oid))
            os_layout.addWidget(rb)
            self.os_buttons.addButton(rb)
        
        layout.addWidget(os_group)
        
        layout.addSpacing(20)
        
        # Кнопки навигации
        btn_layout = QHBoxLayout()
        
        back_btn = QPushButton("◀ Назад")
        back_btn.setObjectName("secondaryBtn")
        back_btn.clicked.emit()
        btn_layout.addWidget(back_btn)
        
        next_btn = QPushButton("Далее ▶")
        next_btn.clicked.emit()
        btn_layout.addWidget(next_btn)
        
        layout.addLayout(btn_layout)
        
        self.backClicked = back_btn.clicked
        self.nextClicked = next_btn.clicked
        
        self.setLayout(layout)
    
    def detect_os(self):
        import platform
        system = platform.system()
        if system == "Linux":
            return "Linux"
        elif system == "Darwin":
            return "macOS"
        else:
            return "Windows"
    
    def on_toggled(self, checked, os_id):
        if checked:
            self.selected_os = os_id


class ActionPage(QWidget):
    def __init__(self):
        super().__init__()
        self.selected_action = "install"
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Выберите действие")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Группа с действиями
        action_group = QGroupBox("Действие")
        action_layout = QVBoxLayout(action_group)
        
        self.action_buttons = QButtonGroup(self)
        
        actions = [
            ("install", "📦 Установить Mirror Language"),
            ("uninstall", "🗑️ Удалить Mirror Language"),
        ]
        
        for action_id, action_text in actions:
            rb = QRadioButton(action_text)
            if action_id == "install":
                rb.setChecked(True)
            rb.toggled.connect(lambda checked, aid=action_id: self.on_toggled(checked, aid))
            action_layout.addWidget(rb)
            self.action_buttons.addButton(rb)
        
        layout.addWidget(action_group)
        
        layout.addSpacing(20)
        
        # Кнопки навигации
        btn_layout = QHBoxLayout()
        
        back_btn = QPushButton("◀ Назад")
        back_btn.setObjectName("secondaryBtn")
        back_btn.clicked.emit()
        btn_layout.addWidget(back_btn)
        
        next_btn = QPushButton("Выполнить ▶")
        next_btn.clicked.emit()
        btn_layout.addWidget(next_btn)
        
        layout.addLayout(btn_layout)
        
        self.backClicked = back_btn.clicked
        self.nextClicked = next_btn.clicked
        
        self.setLayout(layout)
    
    def on_toggled(self, checked, action_id):
        if checked:
            self.selected_action = action_id


class ProgressPage(QWidget):
    def __init__(self, script_dir):
        super().__init__()
        self.script_dir = script_dir
        self.install_thread = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Установка...")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Прогресс бар
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        
        # Статус
        self.status = QLabel("Инициализация...")
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status)
        
        # Лог
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(200)
        layout.addWidget(self.log)
        
        # Кнопка "Готово"
        self.done_btn = QPushButton("✅ Готово")
        self.done_btn.setEnabled(False)
        self.done_btn.clicked.emit()
        layout.addWidget(self.done_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.setLayout(layout)
    
    def start_install(self, action, os_type):
        self.install_thread = InstallThread(self.script_dir, action, os_type)
        self.install_thread.progress.connect(self.on_progress)
        self.install_thread.finished.connect(self.on_finished)
        self.install_thread.start()
    
    def on_progress(self, value, message):
        self.progress.setValue(value)
        self.status.setText(message)
        self.log.append(f"[{value}%] {message}")
    
    def on_finished(self, success, message):
        self.done_btn.setEnabled(True)
        if success:
            self.status.setText(f"✅ {message}")
        else:
            self.status.setText(f"❌ {message}")


class FinishPage(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Иконка
        icon = QLabel("✅")
        icon.setObjectName("logoLabel")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon)
        
        title = QLabel("Готово!")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # Информация
        info = QLabel("Mirror Language успешно установлен!")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet("font-size: 16px; padding: 20px;")
        layout.addWidget(info)
        
        # Команды
        cmds = QLabel("""
<b>Использование:</b><br>
<code style="background: #1a1a2e; padding: 10px; display: block; margin: 10px;">
mirror program.mirror &nbsp;&nbsp;# Запуск файла<br>
mirror --repl &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Интерактивный режим<br>
mirror --help &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Справка
</code>
        """)
        cmds.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(cmds)
        
        layout.addSpacing(20)
        
        # Кнопка "Закрыть"
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.emit()
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.closeClicked = close_btn.clicked
        
        self.setLayout(layout)


# ============================================================================
# ГЛАВНОЕ ОКНО
# ============================================================================

class InstallerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.script_dir = Path(__file__).parent.resolve()
        self.selected_os = "Linux"
        self.selected_action = "install"
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("🪞 Mirror Language Installer")
        self.setMinimumSize(600, 500)
        self.setStyleSheet(STYLESHEET)
        
        # Центральный виджет
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(40, 40, 40, 40)
        
        # Стек страниц
        self.stack = QStackedWidget()
        
        self.welcome_page = WelcomePage()
        self.os_page = OSPage()
        self.action_page = ActionPage()
        self.progress_page = ProgressPage(str(self.script_dir))
        self.finish_page = FinishPage()
        
        self.stack.addWidget(self.welcome_page)
        self.stack.addWidget(self.os_page)
        self.stack.addWidget(self.action_page)
        self.stack.addWidget(self.progress_page)
        self.stack.addWidget(self.finish_page)
        
        main_layout.addWidget(self.stack)
        
        # Подключения
        self.welcome_page.nextClicked.connect(lambda: self.stack.setCurrentIndex(1))
        self.os_page.backClicked.connect(lambda: self.stack.setCurrentIndex(0))
        self.os_page.nextClicked.connect(lambda: self.stack.setCurrentIndex(2))
        self.action_page.backClicked.connect(lambda: self.stack.setCurrentIndex(1))
        self.action_page.nextClicked.connect(self.start_install)
        self.progress_page.done_btn.clicked.connect(lambda: self.stack.setCurrentIndex(4))
        self.finish_page.closeClicked.connect(self.close)
    
    def start_install(self):
        self.selected_os = self.os_page.selected_os
        self.selected_action = self.action_page.selected_action
        self.stack.setCurrentIndex(3)
        self.progress_page.start_install(self.selected_action, self.selected_os)


# ============================================================================
# ЗАПУСК
# ============================================================================

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    window = InstallerWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
