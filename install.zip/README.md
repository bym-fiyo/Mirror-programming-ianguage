# Mirror Programming Language

Это мой собственный полноценный язык программирования с простым и чистым синтаксисом.

## Особенности

- **Чистый синтаксис** — код читается как обычный текст
- **Отступы вместо скобок** — 4 пробела для вложенности
- **95+ встроенных функций** — работа со строками, файлами, криптографией, JSON
- **Зеркальные функции** — уникальная возможность выполнения кода в обратном порядке
- **Макросы** — метапрограммирование для генерации кода

## Зеркальные функции (mirrorfunc)

Mirror — первый язык с поддержкой зеркальных функций, которые выполняют код в обратном порядке:

```mirror
mirrorfunc test():
    echo "first"
    echo "second"
    echo "third"

test()  # Выведет: third, second, first
```

## Макросы (macro)

Макросы позволяют создавать код, который генерирует другой код:

```mirror
# Макрос отладки
macro debug(var_name):
    echo("DEBUG: " + var_name + " = ")
    ret var_name

var x = 42
debug!(x)  # Вывод: DEBUG: x = \n 42

# Макрос unless
macro unless(condition, code):
    if not condition:
        ret code
    ret nil

unless!(x > 10, echo("small"))  # Вывод: small

# Макрос repeat
macro repeat(n, code):
    for i in range(n):
        code
    ret nil

repeat!(3, echo("Hi"))  # Вывод: Hi (3 раза)
```

## Установка

### Linux/macOS

```bash
# Установите зависимости
sudo apt-get install gcc libssl-dev  # Debian/Ubuntu
sudo dnf install gcc openssl-devel   # Fedora

# Скомпилируйте интерпретатор
gcc -o mirror mirror.c -lm -lssl -lcrypto -O2

# Установите в систему
sudo cp mirror /usr/local/bin/
sudo chmod +x /usr/local/bin/mirror

# Проверьте установку
mirror --version
```

### Запуск программ

```bash
mirror program.mirror
```

### Интерактивный режим (REPL)

```bash
mirror --repl
```

## Примеры

### Hello, World!

```mirror
echo("Hello, World!")
```

### Переменные

```mirror
var name = "Alice"
var age = 25
var active = yes
```

### Функции

```mirror
func greet(person):
    ret "Hello, " + person + "!"

echo(greet("Alice"))  # Hello, Alice!
```

### Условия

```mirror
if age >= 18:
    echo("Adult")
else:
    echo("Minor")
```

### Циклы

```mirror
for i in range(5):
    echo(i)  # 0, 1, 2, 3, 4
```

### Обработка ошибок

```mirror
try:
    var result = 10 / 0
catch(e):
    echo("Error: " + str(e))
```

## Документация

Полная документация доступна в файлах:
- `index.html` — главная страница с описанием
- `docs.html` — полная документация по языку

## Лицензия

Open Source проект. Используйте свободно!
